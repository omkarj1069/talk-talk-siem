"""
TalkTalk Lab — Mini-SIEM  ·  Flask application factory
"""
import logging
import os
from pathlib import Path

from flask import Flask, redirect, url_for
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect

from .db import migrate, init_app as db_init_app
from .auth import init_login_manager


def create_app(config_override=None):
    app = Flask(__name__, instance_relative_config=False)

    # ── Load config ────────────────────────────────────────────────────────
    app.config.from_object("config")
    if config_override:
        app.config.update(config_override)

    # ── Logging ────────────────────────────────────────────────────────────
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )

    # ── Ensure data directories ────────────────────────────────────────────
    for d in [app.config["DATA_DIR"], app.config["RUNS_DIR"], app.config["EVIDENCE_DIR"]]:
        Path(str(d)).mkdir(parents=True, exist_ok=True)

    # ── Database migrations ────────────────────────────────────────────────
    migrate(app.config["DATABASE"])
    db_init_app(app)

    # ── CSRF ───────────────────────────────────────────────────────────────
    csrf = CSRFProtect(app)

    # ── Authentication ─────────────────────────────────────────────────────
    init_login_manager(app)

    # ── Import historical runs at startup ──────────────────────────────────
    with app.app_context():
        from .importer import import_historical_runs_if_needed
        import_historical_runs_if_needed()

    # ── Blueprints ─────────────────────────────────────────────────────────
    from .blueprints.overview import bp as overview_bp
    from .blueprints.attacklab import bp as attacklab_bp
    from .blueprints.incidents import bp as incidents_bp
    from .blueprints.results import bp as results_bp
    from .blueprints.api import bp as api_bp

    app.register_blueprint(overview_bp)
    app.register_blueprint(attacklab_bp)
    app.register_blueprint(incidents_bp)
    app.register_blueprint(results_bp)
    app.register_blueprint(api_bp)

    @app.route("/")
    def index():
        return redirect(url_for("overview.index"))

    # ── Context processor — fixture mode badge ─────────────────────────────
    @app.context_processor
    def inject_globals():
        return {
            "FIXTURE_MODE": app.config.get("FIXTURE_MODE", False),
            "APP_NAME": "TalkTalk Lab \u2014 Mini-SIEM",
            "POLL_INTERVAL_MS": app.config.get("POLL_INTERVAL_MS", 5000),
        }

    return app
