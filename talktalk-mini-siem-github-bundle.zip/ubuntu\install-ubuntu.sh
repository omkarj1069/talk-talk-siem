#!/bin/bash
# TalkTalk Lab — Mini-SIEM · Ubuntu install script
# Run as: sudo bash install-ubuntu.sh
# Creates service accounts, installs systemd units, configures sudoers.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="/opt/tt-siem"
CONFIG_DIR="/etc/tt-siem"
DATA_DIR="/var/lib/tt-siem"
LOG_DIR="/var/log/tt-siem"

echo "=== TalkTalk Lab Mini-SIEM Ubuntu Install ==="

# ── Create service user ────────────────────────────────────────────────────────
if ! id tt-siem >/dev/null 2>&1; then
    useradd --system --no-create-home --shell /bin/false --groups adm tt-siem
    echo "Created user: tt-siem (member of adm for log reading)"
fi

# ── Directories ────────────────────────────────────────────────────────────────
mkdir -p "$INSTALL_DIR" "$CONFIG_DIR" "$DATA_DIR" "$LOG_DIR"
chown tt-siem:tt-siem "$DATA_DIR" "$LOG_DIR"

# ── Copy scripts ───────────────────────────────────────────────────────────────
cp "$SCRIPT_DIR/tt-collector.py"       "$INSTALL_DIR/"
cp "$SCRIPT_DIR/tt-response-helper.py" "$INSTALL_DIR/"
cp "$SCRIPT_DIR/operator-switch.sh"    "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR/"*.sh

# ── Config templates (if not already present) ──────────────────────────────────
if [[ ! -f "$CONFIG_DIR/collector.conf" ]]; then
    cat > "$CONFIG_DIR/collector.conf" <<'EOF'
# TalkTalk Mini-SIEM collector configuration
# REQUIRED: set collector_token to match COLLECTOR_TOKEN in Windows config
collector_token=CHANGE_ME_COLLECTOR_TOKEN

apache_log=/var/log/apache2/access.log
suricata_eve=/var/log/suricata/eve.json
checkpoint_file=/var/lib/tt-siem/collector.checkpoint.json
backend_url=http://192.168.77.1:8080/api/collector/ingest
flush_interval_sec=5
max_batch_size=50
request_timeout=15
heartbeat_interval=30
log_level=INFO
EOF
    chmod 600 "$CONFIG_DIR/collector.conf"
    chown tt-siem:tt-siem "$CONFIG_DIR/collector.conf"
    echo "Created $CONFIG_DIR/collector.conf — EDIT collector_token before starting"
fi

if [[ ! -f "$CONFIG_DIR/helper.conf" ]]; then
    cat > "$CONFIG_DIR/helper.conf" <<'EOF'
# TalkTalk Mini-SIEM response helper configuration
# REQUIRED: set token to match RESPONSE_HELPER_TOKEN in Windows config
token=CHANGE_ME_HELPER_TOKEN
listen_port=9120
EOF
    chmod 600 "$CONFIG_DIR/helper.conf"
    chown tt-siem:tt-siem "$CONFIG_DIR/helper.conf"
    echo "Created $CONFIG_DIR/helper.conf — EDIT token before starting"
fi

# ── sudoers for response helper ────────────────────────────────────────────────
cat > /etc/sudoers.d/tt-siem-helper <<'EOF'
# TalkTalk Mini-SIEM — response helper restricted iptables access
# Only TT-SIEM chain — does not modify or flush existing firewall rules
tt-siem ALL=(root) NOPASSWD: /usr/sbin/iptables -N TT-SIEM
tt-siem ALL=(root) NOPASSWD: /usr/sbin/iptables -C INPUT -j TT-SIEM
tt-siem ALL=(root) NOPASSWD: /usr/sbin/iptables -I INPUT -j TT-SIEM
tt-siem ALL=(root) NOPASSWD: /usr/sbin/iptables -I TT-SIEM *
tt-siem ALL=(root) NOPASSWD: /usr/sbin/iptables -D TT-SIEM *
tt-siem ALL=(root) NOPASSWD: /usr/sbin/iptables -F TT-SIEM
tt-siem ALL=(root) NOPASSWD: /usr/sbin/iptables -L TT-SIEM -n
EOF
chmod 440 /etc/sudoers.d/tt-siem-helper
visudo -c -f /etc/sudoers.d/tt-siem-helper && echo "sudoers OK"

# ── systemd units ──────────────────────────────────────────────────────────────
cat > /etc/systemd/system/tt-siem-collector.service <<EOF
[Unit]
Description=TalkTalk Mini-SIEM Collector
After=network.target
Wants=network.target

[Service]
Type=simple
User=tt-siem
ExecStart=/usr/bin/python3 $INSTALL_DIR/tt-collector.py --config $CONFIG_DIR/collector.conf
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/tt-siem-helper.service <<EOF
[Unit]
Description=TalkTalk Mini-SIEM Response Helper
After=network.target

[Service]
Type=simple
User=tt-siem
EnvironmentFile=-$CONFIG_DIR/helper-env
ExecStart=/usr/bin/python3 $INSTALL_DIR/tt-response-helper.py
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
echo ""
echo "=== Installation complete ==="
echo ""
echo "NEXT STEPS:"
echo "  1. Edit $CONFIG_DIR/collector.conf — set collector_token"
echo "  2. Edit $CONFIG_DIR/helper.conf    — set token"
echo "  3. Create $CONFIG_DIR/helper-env   with: TT_HELPER_TOKEN=<same_token>"
echo "  4. systemctl enable --now tt-siem-collector"
echo "  5. systemctl enable --now tt-siem-helper"
echo ""
echo "Health check:"
echo "  systemctl status tt-siem-collector"
echo "  systemctl status tt-siem-helper"
echo "  curl -s http://127.0.0.1:9120/health -H 'X-Helper-Token: <token>'"
