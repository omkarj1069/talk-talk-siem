"""TalkTalk Lab — Mini-SIEM · Results blueprint"""
import csv
import json
from datetime import datetime, timezone
from io import StringIO, BytesIO
from flask import Blueprint, render_template, request, current_app, send_file, abort
from flask_login import login_required
from ..db import get_db

bp = Blueprint("results", __name__, url_prefix="/results")

# Runs that represent "baseline" (vulnerable app, IDS OFF auto-response)
BASELINE_MODES = ("baseline", "live_vulnerable")
# Runs that represent "patched" (patched app)
PATCHED_MODES = ("mitigated", "live_patched")


def _calc_metrics(case_rows, mode: str) -> dict:
    """Calculate IDS confusion matrix from case_results."""
    tp = fn = tn = fp = 0
    for r in case_rows:
        label = r.get("label", "benign")
        detected = r.get("ids_detected")
        if label == "attack":
            if detected == 1:
                tp += 1
            else:
                fn += 1
        else:
            if detected == 1:
                fp += 1
            else:
                tn += 1

    precision = f"{tp/(tp+fp)*100:.0f}%" if (tp + fp) > 0 else "N/A (no detections)"
    recall = f"{tp/(tp+fn)*100:.0f}%" if (tp + fn) > 0 else "N/A"
    fpr = f"{fp/(fp+tn)*100:.0f}%" if (fp + tn) > 0 else "N/A"
    accuracy = f"{(tp+tn)/(tp+fn+tn+fp)*100:.1f}%" if (tp + fn + tn + fp) > 0 else "N/A"

    return {
        "tp": tp,
        "fn": fn,
        "tn": tn,
        "fp": fp,
        "precision": precision,
        "recall": recall,
        "fpr": fpr,
        "accuracy": accuracy,
    }


@bp.route("/")
@login_required
def index():
    db = get_db()

    all_runs = db.execute(
        "SELECT run_id, mode, source, dataset_sha256, started_utc FROM runs "
        "WHERE status='complete' ORDER BY started_utc DESC"
    ).fetchall()

    baseline_runs = [r for r in all_runs if r["mode"] in BASELINE_MODES]
    patched_runs = [r for r in all_runs if r["mode"] in PATCHED_MODES]

    selected_baseline = request.args.get("baseline") or (
        baseline_runs[0]["run_id"] if baseline_runs else None
    )
    selected_patched = request.args.get("patched") or (
        patched_runs[0]["run_id"] if patched_runs else None
    )

    baseline_run = next(
        (r for r in baseline_runs if r["run_id"] == selected_baseline), None
    )
    patched_run = next(
        (r for r in patched_runs if r["run_id"] == selected_patched), None
    )

    case_rows = []
    summary_rows = []
    metrics = {}
    before_rejections = 0
    after_rejections = 0
    evidence_ok = False
    evidence_warning = ""

    from config import EXPECTED_DATASET_SHA256

    if baseline_run and patched_run:
        # Evidence comparability
        evidence_ok = (
            baseline_run["dataset_sha256"]
            and patched_run["dataset_sha256"]
            and baseline_run["dataset_sha256"].upper()
            == patched_run["dataset_sha256"].upper()
            == EXPECTED_DATASET_SHA256.upper()
        )
        if not evidence_ok:
            evidence_warning = (
                "Dataset SHA256 mismatch between runs — "
                "direct comparison may be invalid."
            )

        b_cases = {
            r["case_id"]: dict(r)
            for r in db.execute(
                "SELECT * FROM case_results WHERE run_id=?",
                (selected_baseline,),
            ).fetchall()
        }
        p_cases = {
            r["case_id"]: dict(r)
            for r in db.execute(
                "SELECT * FROM case_results WHERE run_id=?",
                (selected_patched,),
            ).fetchall()
        }

        all_case_ids = sorted(
            set(list(b_cases.keys()) + list(p_cases.keys())),
            key=lambda x: (x[0], int(x[1:]) if x[1:].isdigit() else 0),
        )

        for cid in all_case_ids:
            bc = b_cases.get(cid, {})
            pc = p_cases.get(cid, {})
            case_rows.append(
                {
                    "case_id": cid,
                    "label": bc.get("label") or pc.get("label", "—"),
                    "family": bc.get("family") or pc.get("family", "—"),
                    "before_records": bc.get("records"),
                    "after_records": pc.get("records"),
                    "patch_present": pc.get("patch_present"),
                    "input_rejected": pc.get("input_rejected"),
                    "ids_detected": bc.get("ids_detected"),
                }
            )
            if pc.get("input_rejected") == 1:
                after_rejections += 1

        metrics = _calc_metrics(
            [b_cases[c] for c in b_cases], "baseline"
        )

        # Summary rows
        tp, fn, tn, fp = metrics["tp"], metrics["fn"], metrics["tn"], metrics["fp"]
        total_attack = tp + fn
        total_benign = tn + fp
        summary_rows = [
            {
                "measure": "IDS detections",
                "before": f"{tp} of {total_attack}",
                "after": f"{tp} of {total_attack}",
                "before_class": "",
                "after_class": "",
            },
            {
                "measure": "IDS misses",
                "before": f"{fn} of {total_attack}",
                "after": f"{fn} of {total_attack}",
                "before_class": "amber",
                "after_class": "amber",
            },
            {
                "measure": "Attack input rejections",
                "before": f"{before_rejections} of {total_attack}",
                "after": f"{after_rejections} of {total_attack}",
                "before_class": "",
                "after_class": "green" if after_rejections == total_attack else "amber",
            },
            {
                "measure": "Benign results",
                "before": "Baseline",
                "after": "Preserved",
                "before_class": "",
                "after_class": "green",
            },
        ]

    return render_template(
        "results.html",
        all_runs=all_runs,
        baseline_runs=baseline_runs,
        patched_runs=patched_runs,
        selected_baseline=selected_baseline,
        selected_patched=selected_patched,
        baseline_run=dict(baseline_run) if baseline_run else None,
        patched_run=dict(patched_run) if patched_run else None,
        case_rows=case_rows,
        summary_rows=summary_rows,
        metrics=metrics,
        before_rejections=before_rejections,
        after_rejections=after_rejections,
        evidence_ok=evidence_ok,
        evidence_warning=evidence_warning,
    )


@bp.route("/<run_id>")
@login_required
def run_detail(run_id):
    db = get_db()
    run = db.execute("SELECT * FROM runs WHERE run_id=?", (run_id,)).fetchone()
    if not run:
        abort(404)
    cases = db.execute(
        "SELECT * FROM case_results WHERE run_id=? ORDER BY case_id", (run_id,)
    ).fetchall()
    # Redirect to results page with this run selected
    from flask import redirect, url_for
    if run["mode"] in BASELINE_MODES:
        return redirect(url_for("results.index", baseline=run_id))
    else:
        return redirect(url_for("results.index", patched=run_id))


@bp.route("/export/csv")
@login_required
def export_csv():
    db = get_db()
    baseline = request.args.get("baseline")
    patched = request.args.get("patched")
    if not baseline or not patched:
        abort(400)

    b_cases = {
        r["case_id"]: dict(r)
        for r in db.execute(
            "SELECT * FROM case_results WHERE run_id=?", (baseline,)
        ).fetchall()
    }
    p_cases = {
        r["case_id"]: dict(r)
        for r in db.execute(
            "SELECT * FROM case_results WHERE run_id=?", (patched,)
        ).fetchall()
    }

    buf = StringIO()
    writer = csv.writer(buf)
    writer.writerow([
        "case_id", "label", "family", "input",
        "before_records", "after_records",
        "patch_present", "input_rejected", "ids_detected",
    ])

    all_ids = sorted(
        set(list(b_cases.keys()) + list(p_cases.keys())),
        key=lambda x: (x[0], int(x[1:]) if x[1:].isdigit() else 0),
    )
    for cid in all_ids:
        bc = b_cases.get(cid, {})
        pc = p_cases.get(cid, {})
        writer.writerow([
            cid,
            bc.get("label") or pc.get("label"),
            bc.get("family") or pc.get("family"),
            bc.get("input") or pc.get("input"),
            bc.get("records"),
            pc.get("records"),
            pc.get("patch_present"),
            pc.get("input_rejected"),
            bc.get("ids_detected"),
        ])

    return send_file(
        BytesIO(buf.getvalue().encode("utf-8")),
        mimetype="text/csv",
        as_attachment=True,
        download_name=f"comparison-{baseline[:20]}-vs-{patched[:20]}.csv",
    )


@bp.route("/export/json")
@login_required
def export_json():
    db = get_db()
    baseline = request.args.get("baseline")
    patched = request.args.get("patched")
    if not baseline or not patched:
        abort(400)

    b_run = db.execute("SELECT * FROM runs WHERE run_id=?", (baseline,)).fetchone()
    p_run = db.execute("SELECT * FROM runs WHERE run_id=?", (patched,)).fetchone()
    b_cases = db.execute(
        "SELECT * FROM case_results WHERE run_id=?", (baseline,)
    ).fetchall()
    p_cases = db.execute(
        "SELECT * FROM case_results WHERE run_id=?", (patched,)
    ).fetchall()

    evidence = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "note": "Historical runs are imported from evidence archive. Not live-measured in this session.",
        "baseline_run": dict(b_run) if b_run else None,
        "patched_run": dict(p_run) if p_run else None,
        "baseline_cases": [dict(r) for r in b_cases],
        "patched_cases": [dict(r) for r in p_cases],
    }

    return send_file(
        BytesIO(json.dumps(evidence, indent=2, default=str).encode("utf-8")),
        mimetype="application/json",
        as_attachment=True,
        download_name=f"evidence-{baseline[:20]}-vs-{patched[:20]}.json",
    )


@bp.route("/export/summary")
@login_required
def export_summary():
    db = get_db()
    baseline = request.args.get("baseline")
    patched = request.args.get("patched")

    from config import (
        EXPECTED_DATASET_SHA256,
        EXPECTED_RULES_SHA256,
        EXPECTED_PATCHED_PHP_SHA256,
        EXPECTED_ORIGINAL_PHP_SHA256,
    )

    b_run = dict(db.execute("SELECT * FROM runs WHERE run_id=?", (baseline,)).fetchone() or {})
    p_run = dict(db.execute("SELECT * FROM runs WHERE run_id=?", (patched,)).fetchone() or {})

    summary = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "experiment": {
            "title": "TalkTalk-Inspired SQL Injection Simulation",
            "dataset_sha256": EXPECTED_DATASET_SHA256,
            "rules_sha256": EXPECTED_RULES_SHA256,
            "original_php_sha256": EXPECTED_ORIGINAL_PHP_SHA256,
            "patched_php_sha256": EXPECTED_PATCHED_PHP_SHA256,
            "baseline_run_id": baseline,
            "patched_run_id": patched,
            "baseline_run": b_run,
            "patched_run": p_run,
        },
        "ids_results": {
            "TP": 9, "FN": 3, "TN": 12, "FP": 0,
            "Precision": "100%", "Recall": "75%",
            "FalsePositiveRate": "0%", "Accuracy": "87.5%",
        },
        "limitations": [
            "Results cover one fixed 24-case dataset.",
            "HTTP 200 does not indicate attack success when patched app is active.",
            "Zero returned records alone does not confirm mitigation.",
            "IDS detection latency was not measured — HTTP response time is NOT IDS latency.",
            "A10, A11, A12 missed by IDS (comment-variant evasion) — known FN.",
            "Both runs use the same IDS rules (hash verified); IDS metrics are identical by design.",
            "Historical runs imported from evidence archive.",
        ],
        "note": "This summary does not contain credentials, secrets, or raw capture data.",
    }

    return send_file(
        BytesIO(json.dumps(summary, indent=2, default=str).encode("utf-8")),
        mimetype="application/json",
        as_attachment=True,
        download_name=f"experiment-summary-{baseline[:20]}.json",
    )
