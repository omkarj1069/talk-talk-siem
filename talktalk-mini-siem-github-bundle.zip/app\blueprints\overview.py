"""TalkTalk Lab — Mini-SIEM · Overview blueprint"""
from datetime import datetime, timezone, timedelta
from flask import Blueprint, render_template
from flask_login import login_required
from ..db import get_db

bp = Blueprint("overview", __name__)


def _utc_to_local_str(utc_str: str) -> str:
    if not utc_str:
        return "—"
    try:
        dt = datetime.fromisoformat(utc_str.replace("Z", "+00:00"))
        local = dt.astimezone()
        return local.strftime("%H:%M:%S")
    except Exception:
        return utc_str[:19]


@bp.route("/overview")
@login_required
def index():
    db = get_db()
    now_utc = datetime.now(timezone.utc)

    # Metrics
    request_count = db.execute(
        "SELECT COUNT(*) FROM case_results"
    ).fetchone()[0]
    alert_count = db.execute(
        "SELECT COUNT(*) FROM alerts"
    ).fetchone()[0]
    incident_count = db.execute(
        "SELECT COUNT(*) FROM incidents WHERE status != 'resolved'"
    ).fetchone()[0]
    active_blocks = db.execute(
        "SELECT COUNT(*) FROM response_actions WHERE status IN ('applied','verified')"
    ).fetchone()[0]

    metrics = {
        "request_count": request_count,
        "alert_count": alert_count,
        "incident_count": incident_count,
        "active_blocks": active_blocks,
    }

    # Service status (from collector heartbeat)
    collector_fresh_utc = db.execute(
        "SELECT value FROM siem_settings WHERE key='collector_fresh_utc'"
    ).fetchone()
    collector_last = None
    collector_fresh = False
    if collector_fresh_utc and collector_fresh_utc[0]:
        try:
            last = datetime.fromisoformat(
                collector_fresh_utc[0].replace("Z", "+00:00")
            )
            age = (now_utc - last).total_seconds()
            collector_fresh = age < 120  # stale after 2 minutes
            collector_last = last.astimezone().strftime("%H:%M:%S")
        except Exception:
            pass

    services = {
        "ubuntu": "online" if collector_fresh else "unknown",
        "apache": "unknown",
        "suricata": "unknown",
    }

    # App state
    app_state_row = db.execute(
        "SELECT state, php_sha256, checked_utc FROM app_state WHERE id=1"
    ).fetchone()
    app_state = {
        "state": app_state_row["state"] if app_state_row else "unknown",
        "sha256": app_state_row["php_sha256"] if app_state_row else None,
    }

    # Auto-response setting
    ar_row = db.execute(
        "SELECT value FROM siem_settings WHERE key='auto_response'"
    ).fetchone()
    auto_response = ar_row and ar_row[0] == "1"

    # Activity chart — last 30 minutes in 5-min buckets
    labels = []
    normal_counts = []
    attack_counts = []
    for i in range(6):
        bucket_start = now_utc - timedelta(minutes=30 - i * 5)
        bucket_end = bucket_start + timedelta(minutes=5)
        label = bucket_start.strftime("%H:%M")
        labels.append(label)
        s = bucket_start.isoformat()
        e = bucket_end.isoformat()
        n_count = db.execute(
            "SELECT COUNT(*) FROM case_results WHERE label='benign' "
            "AND started_utc >= ? AND started_utc < ?",
            (s, e),
        ).fetchone()[0]
        a_count = db.execute(
            "SELECT COUNT(*) FROM case_results WHERE label='attack' "
            "AND started_utc >= ? AND started_utc < ?",
            (s, e),
        ).fetchone()[0]
        normal_counts.append(n_count)
        attack_counts.append(a_count)

    activity_chart_data = {
        "labels": labels,
        "normal": normal_counts,
        "attack": attack_counts,
    }

    # Recent events — combine alerts and case_results
    recent_events = []

    recent_alerts = db.execute(
        "SELECT timestamp_utc, rule_sid, rule_name, src_ip, http_url "
        "FROM alerts ORDER BY timestamp_utc DESC LIMIT 5"
    ).fetchall()
    for a in recent_alerts:
        recent_events.append(
            {
                "time_local": _utc_to_local_str(a["timestamp_utc"]),
                "event_type": "SQL injection alert",
                "detail": a["http_url"] or f"SID {a['rule_sid']}",
                "badge_class": "badge-red",
                "badge_label": "Alert raised",
            }
        )

    recent_cases = db.execute(
        "SELECT started_utc, case_id, label, input, request_url "
        "FROM case_results ORDER BY started_utc DESC LIMIT 5"
    ).fetchall()
    for c in recent_cases:
        badge_class = "badge-red" if c["label"] == "attack" else "badge-blue"
        badge_label = "Attack input" if c["label"] == "attack" else "Allowed"
        recent_events.append(
            {
                "time_local": _utc_to_local_str(c["started_utc"]),
                "event_type": "Normal lookup"
                if c["label"] == "benign"
                else "SQL injection",
                "detail": c["request_url"]
                or f"id={c['input'][:30]}",
                "badge_class": badge_class,
                "badge_label": badge_label,
            }
        )

    recent_incidents = db.execute(
        "SELECT created_utc, incident_id, source_ip "
        "FROM incidents ORDER BY created_utc DESC LIMIT 3"
    ).fetchall()
    for i in recent_incidents:
        recent_events.append(
            {
                "time_local": _utc_to_local_str(i["created_utc"]),
                "event_type": "Incident opened",
                "detail": f"{i['incident_id']} — {i['source_ip']}",
                "badge_class": "badge-amber",
                "badge_label": "Incident opened",
            }
        )

    # Sort by time desc, keep top 8
    recent_events.sort(key=lambda x: x["time_local"], reverse=True)
    recent_events = recent_events[:8]

    from config import EXPECTED_DATASET_SHA256, EXPECTED_RULES_SHA256

    return render_template(
        "overview.html",
        metrics=metrics,
        services=services,
        app_state=app_state,
        auto_response=auto_response,
        collector_fresh=collector_fresh,
        collector_last=collector_last,
        recent_events=recent_events,
        activity_chart_data=activity_chart_data,
        dataset_hash=EXPECTED_DATASET_SHA256,
        rules_hash=EXPECTED_RULES_SHA256,
    )
