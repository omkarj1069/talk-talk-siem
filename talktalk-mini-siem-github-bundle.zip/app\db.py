"""
TalkTalk Lab — Mini-SIEM  ·  Database module
SQLite with explicit migrations.  Connection is always opened per-request
using Flask's g object.  No ORM; raw SQL for transparency and portability.
"""
import sqlite3
import logging
from pathlib import Path
from flask import g, current_app

log = logging.getLogger(__name__)

# ── Schema migrations ─────────────────────────────────────────────────────────
# Append-only list; never delete or reorder entries.
MIGRATIONS = [
    # 0 — initial schema
    """
    CREATE TABLE IF NOT EXISTS schema_version (
        id      INTEGER PRIMARY KEY CHECK (id = 1),
        version INTEGER NOT NULL DEFAULT 0
    );
    INSERT OR IGNORE INTO schema_version (id, version) VALUES (1, 0);

    CREATE TABLE IF NOT EXISTS events (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        source        TEXT    NOT NULL,          -- 'apache' | 'suricata'
        event_type    TEXT    NOT NULL,
        raw           TEXT    NOT NULL,
        timestamp_utc TEXT    NOT NULL,
        dedup_key     TEXT    UNIQUE NOT NULL,   -- prevents double-ingestion
        ingested_utc  TEXT    NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_events_ts  ON events (timestamp_utc);
    CREATE INDEX IF NOT EXISTS idx_events_src ON events (source);

    CREATE TABLE IF NOT EXISTS runs (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        run_id          TEXT    UNIQUE NOT NULL,
        mode            TEXT    NOT NULL,   -- 'baseline'|'mitigated'|'live_vulnerable'|'live_patched'|'fixture'
        source          TEXT    NOT NULL,   -- 'historical'|'live'|'fixture'
        started_utc     TEXT    NOT NULL,
        finished_utc    TEXT,
        status          TEXT    NOT NULL DEFAULT 'running',  -- 'running'|'complete'|'cancelled'|'error'
        dataset_sha256  TEXT,
        rules_sha256    TEXT,
        app_sha256      TEXT,
        auto_response   INTEGER NOT NULL DEFAULT 0,
        case_count      INTEGER NOT NULL DEFAULT 0,
        notes           TEXT,
        created_utc     TEXT    NOT NULL
    );

    CREATE TABLE IF NOT EXISTS case_results (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        run_id          TEXT    NOT NULL REFERENCES runs(run_id),
        case_id         TEXT    NOT NULL,
        label           TEXT    NOT NULL,
        family          TEXT    NOT NULL,
        input           TEXT    NOT NULL,
        started_utc     TEXT,
        finished_utc    TEXT,
        http_status     INTEGER,
        response_ms     REAL,
        records         INTEGER,
        patch_present   INTEGER,            -- NULL=not checked, 0=absent, 1=present
        input_rejected  INTEGER,            -- NULL=not checked, 0=not rejected, 1=rejected
        request_url     TEXT,
        response_file   TEXT,
        ids_alert_id    INTEGER,
        ids_rule_sid    TEXT,
        ids_detected    INTEGER,            -- NULL=unknown, 0=no, 1=yes
        error           TEXT,
        UNIQUE(run_id, case_id)
    );

    CREATE TABLE IF NOT EXISTS alerts (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        alert_id      TEXT    UNIQUE NOT NULL,
        timestamp_utc TEXT    NOT NULL,
        rule_sid      TEXT,
        rule_name     TEXT,
        severity      INTEGER,
        src_ip        TEXT,
        dst_ip        TEXT,
        dst_port      INTEGER,
        proto         TEXT,
        http_url      TEXT,
        http_method   TEXT,
        run_id        TEXT,
        case_id       TEXT,
        raw           TEXT    NOT NULL,
        ingested_utc  TEXT    NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_alerts_ts  ON alerts (timestamp_utc);
    CREATE INDEX IF NOT EXISTS idx_alerts_src ON alerts (src_ip);

    CREATE TABLE IF NOT EXISTS incidents (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        incident_id     TEXT    UNIQUE NOT NULL,
        severity        TEXT    NOT NULL DEFAULT 'high',
        status          TEXT    NOT NULL DEFAULT 'open',  -- 'open'|'acknowledged'|'resolved'
        source_ip       TEXT    NOT NULL,
        target_ip       TEXT,
        first_seen_utc  TEXT    NOT NULL,
        last_seen_utc   TEXT    NOT NULL,
        alert_count     INTEGER NOT NULL DEFAULT 1,
        notes           TEXT,
        created_utc     TEXT    NOT NULL,
        updated_utc     TEXT    NOT NULL
    );

    CREATE TABLE IF NOT EXISTS response_actions (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        incident_id     TEXT    NOT NULL REFERENCES incidents(incident_id),
        action          TEXT    NOT NULL,   -- 'block'|'unblock'
        status          TEXT    NOT NULL,   -- 'requested'|'applied'|'verified'|'failed'|'expired'|'manually_removed'
        source_ip       TEXT    NOT NULL,
        target_ip       TEXT    NOT NULL,
        target_port     INTEGER NOT NULL,
        duration_sec    INTEGER,
        requested_utc   TEXT    NOT NULL,
        applied_utc     TEXT,
        verified_utc    TEXT,
        expires_utc     TEXT,
        removed_utc     TEXT,
        verification    TEXT,   -- 'blocked'|'timeout'|'refused'|'other'|NULL
        error           TEXT,
        created_utc     TEXT    NOT NULL
    );

    CREATE TABLE IF NOT EXISTS collector_checkpoints (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        log_path    TEXT    UNIQUE NOT NULL,
        byte_offset INTEGER NOT NULL DEFAULT 0,
        inode       INTEGER,
        updated_utc TEXT    NOT NULL
    );

    CREATE TABLE IF NOT EXISTS audit_log (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        actor       TEXT    NOT NULL,  -- 'system'|'operator'|'scheduler'
        action      TEXT    NOT NULL,
        detail      TEXT,
        created_utc TEXT    NOT NULL
    );

    CREATE TABLE IF NOT EXISTS app_state (
        id           INTEGER PRIMARY KEY CHECK (id = 1),
        php_sha256   TEXT,
        state        TEXT    NOT NULL DEFAULT 'unknown',  -- 'original'|'patched'|'unknown'
        checked_utc  TEXT
    );
    INSERT OR IGNORE INTO app_state (id, state) VALUES (1, 'unknown');

    CREATE TABLE IF NOT EXISTS siem_settings (
        key   TEXT PRIMARY KEY,
        value TEXT NOT NULL
    );
    INSERT OR IGNORE INTO siem_settings VALUES ('auto_response', '0');
    INSERT OR IGNORE INTO siem_settings VALUES ('collector_fresh_utc', '');
    """,
]


def get_db():
    """Return a per-request SQLite connection stored in Flask g."""
    if "db" not in g:
        db_path = current_app.config["DATABASE"]
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        g.db = sqlite3.connect(db_path, detect_types=sqlite3.PARSE_DECLTYPES)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA journal_mode=WAL")
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db


def close_db(e=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def open_db_direct(db_path: str):
    """Open a direct connection outside a request context (e.g. background threads)."""
    conn = sqlite3.connect(db_path, detect_types=sqlite3.PARSE_DECLTYPES)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def migrate(db_path: str):
    """Apply pending migrations.  Call at application startup."""
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    conn = open_db_direct(db_path)
    try:
        # Create schema_version if it doesn't exist yet
        conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_version "
            "(id INTEGER PRIMARY KEY CHECK (id=1), version INTEGER NOT NULL DEFAULT 0)"
        )
        conn.execute("INSERT OR IGNORE INTO schema_version (id, version) VALUES (1, 0)")
        conn.commit()

        row = conn.execute("SELECT version FROM schema_version WHERE id=1").fetchone()
        current_version = row[0] if row else 0

        for idx, sql in enumerate(MIGRATIONS):
            if idx >= current_version:
                log.info("Applying migration %d", idx)
                conn.executescript(sql)
                conn.execute(
                    "UPDATE schema_version SET version=? WHERE id=1", (idx + 1,)
                )
                conn.commit()
        log.info("Database schema at version %d", len(MIGRATIONS))
    finally:
        conn.close()


def init_app(app):
    app.teardown_appcontext(close_db)
