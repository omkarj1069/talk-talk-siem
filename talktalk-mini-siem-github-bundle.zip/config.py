"""
TalkTalk Lab — Mini-SIEM  ·  Configuration
All addresses, ports, paths, timeouts, thresholds, and credentials are
configurable here or via environment variables.  No credentials appear
in exported reports or source-controlled files.

Fixture mode is activated with:
    FIXTURE_MODE=1 python run.py
or by calling app.config.update(FIXTURE_MODE=True) in tests.
"""
import os
from pathlib import Path

# ── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
RUNS_DIR = DATA_DIR / "runs"
EVIDENCE_DIR = DATA_DIR / "evidence"
CASES_CSV = str(BASE_DIR / "data" / "cases.csv")

# ── Database ──────────────────────────────────────────────────────────────────
DATABASE = str(DATA_DIR / "siem.db")

# ── Flask security ────────────────────────────────────────────────────────────
# Override SECRET_KEY via environment variable before production deployment.
SECRET_KEY = os.environ.get("SIEM_SECRET_KEY", "dev-only-change-me")
WTF_CSRF_ENABLED = True
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = "Lax"

# ── Dashboard auth ────────────────────────────────────────────────────────────
# Change SIEM_ADMIN_PASSWORD in the environment before first run.
ADMIN_USERNAME = os.environ.get("SIEM_ADMIN_USER", "admin")
ADMIN_PASSWORD = os.environ.get("SIEM_ADMIN_PASSWORD", "talktalk-lab")

# ── Lab target — ONLY destination allowed for test requests ──────────────────
LAB_HOST = os.environ.get("LAB_HOST", "192.168.77.10")
LAB_PORT = int(os.environ.get("LAB_PORT", "80"))
LAB_BASE_URL = f"http://{LAB_HOST}/DVWA"
DVWA_SECURITY_LEVEL = "low"

# ── DVWA credentials (kept server-side; never logged or exported) ─────────────
DVWA_USER = os.environ.get("DVWA_USER", "admin")
DVWA_PASS = os.environ.get("DVWA_PASS", "password")

# ── Collector — Ubuntu side ───────────────────────────────────────────────────
# The Ubuntu lightweight collector pushes events over a small HTTPS/HTTP
# channel to /api/collector/ingest on the Windows backend.
# Set a long random token via environment variable.
COLLECTOR_TOKEN = os.environ.get("COLLECTOR_TOKEN", "collector-dev-token")
COLLECTOR_LISTEN_PORT = int(os.environ.get("COLLECTOR_LISTEN_PORT", "9119"))

# Ubuntu log paths (read by collector on Ubuntu, not directly by Windows app)
APACHE_ACCESS_LOG = os.environ.get(
    "APACHE_LOG", "/var/log/apache2/access.log"
)
SURICATA_EVE_JSON = os.environ.get(
    "SURICATA_EVE", "/var/log/suricata/eve.json"
)

# ── Response helper — Ubuntu side ─────────────────────────────────────────────
# Response helper is a separate minimal service running as root-with-restricted
# commands on Ubuntu.  Dashboard communicates via HTTPS/UNIX socket + token.
RESPONSE_HELPER_URL = os.environ.get(
    "RESPONSE_HELPER_URL", f"http://{LAB_HOST}:9120"
)
RESPONSE_HELPER_TOKEN = os.environ.get(
    "RESPONSE_HELPER_TOKEN", "helper-dev-token"
)

# Firewall scope (validated server-side; arbitrary addresses rejected)
BLOCK_SOURCE_IP = "192.168.77.1"
BLOCK_TARGET_IP = LAB_HOST
BLOCK_TARGET_PORT = LAB_PORT
BLOCK_CHAIN = "TT-SIEM"

# ── Automated response defaults ───────────────────────────────────────────────
AUTO_RESPONSE_DEFAULT = False          # OFF by default — must be explicitly enabled
INCIDENT_THRESHOLD = 3                 # alerts within window to trigger block
INCIDENT_WINDOW_SECONDS = 60           # detection window
BLOCK_DURATION_SECONDS = 60            # temporary block duration
ALERT_COLLECTION_WINDOW_SECONDS = 10   # wait after request for IDS alert

# ── Test runner limits ────────────────────────────────────────────────────────
REQUEST_TIMEOUT_SECONDS = 20
MAX_CONCURRENT_RUNS = 1
CASE_INTERVAL_SECONDS = 0.5            # pause between cases

# ── Dataset integrity ─────────────────────────────────────────────────────────
EXPECTED_DATASET_SHA256 = (
    "B956230B821338CDAA760AD501C1492A7464DF885840F9935256AF17C9CE095B"
)
EXPECTED_RULES_SHA256 = (
    "b288024a98faca4cd1731049278a63fba5cb4b40f01aa2a45a835c2afdd18d91"
)
EXPECTED_PATCHED_PHP_SHA256 = (
    "bedfbcf09cecbe7b68fd5815605cad234ea7b7f36a7fd0dd99433d47ba50ce59"
)
EXPECTED_ORIGINAL_PHP_SHA256 = (
    "652bb44d14a9d81c9245f05ed8440beecf7977e982e00d3ddb916126a72e85bf"
)

# ── Fixture / Demo mode ───────────────────────────────────────────────────────
# NEVER mix fixture data with real experiment data.
# When FIXTURE_MODE is True the app displays a persistent red "DEMO / FIXTURE DATA" badge,
# all response actions are disabled, and no real HTTP requests are made.
FIXTURE_MODE = os.environ.get("FIXTURE_MODE", "0") == "1"

# ── Log / evidence retention ──────────────────────────────────────────────────
MAX_EVIDENCE_FILES = 500
MAX_RUN_DIRS = 20

# ── API polling interval for live dashboard updates ───────────────────────────
POLL_INTERVAL_MS = 5000
