#!/usr/bin/env python3
"""
TalkTalk Lab — Mini-SIEM · Ubuntu Response Helper
Minimal HTTP service that applies/removes iptables firewall rules.

SECURITY DESIGN:
- Runs as a separate process with restricted sudo rights.
- Accepts only two commands: block and unblock.
- Validates all parameters before invoking iptables.
- Only manages rules in the TT-SIEM chain.
- Does NOT flush, replace, or disable existing firewall rules.
- Preserves SSH (port 22), collector (port 9119), and management access.
- All actions are logged to syslog.

Requires /etc/sudoers.d/tt-siem-helper with:
  tt-siem ALL=(root) NOPASSWD: /usr/sbin/iptables -I TT-SIEM *
  tt-siem ALL=(root) NOPASSWD: /usr/sbin/iptables -D TT-SIEM *
  tt-siem ALL=(root) NOPASSWD: /usr/sbin/iptables -N TT-SIEM
  tt-siem ALL=(root) NOPASSWD: /usr/sbin/iptables -C INPUT -j TT-SIEM
  tt-siem ALL=(root) NOPASSWD: /usr/sbin/iptables -I INPUT -j TT-SIEM

Deployment:
  systemctl start tt-siem-helper
"""
import ipaddress
import json
import logging
import logging.handlers
import os
import re
import signal
import subprocess
import sys
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

# ── Configuration ─────────────────────────────────────────────────────────────
CONFIG_FILE = "/etc/tt-siem/helper.conf"
HELPER_TOKEN = os.environ.get("TT_HELPER_TOKEN", "")
LISTEN_HOST = "127.0.0.1"   # Listen only on localhost; access via SSH tunnel or loopback
LISTEN_PORT = int(os.environ.get("TT_HELPER_PORT", "9120"))
CHAIN = "TT-SIEM"

# Allowed source IPs for blocking (lab test source only)
ALLOWED_SOURCE_IPS = {"192.168.77.1"}
# Only block traffic to this port on this lab host
ALLOWED_TARGET_PORT = 80
MAX_DURATION_SEC = 3600  # Maximum 1 hour block

# ── Logging ────────────────────────────────────────────────────────────────────
syslog = logging.handlers.SysLogHandler(address="/dev/log")
syslog.setFormatter(logging.Formatter("tt-siem-helper: %(message)s"))
log = logging.getLogger("tt-siem-helper")
log.addHandler(syslog)
log.addHandler(logging.StreamHandler())
log.setLevel(logging.INFO)


def _load_config():
    global HELPER_TOKEN, LISTEN_HOST, LISTEN_PORT
    if Path(CONFIG_FILE).exists():
        try:
            with open(CONFIG_FILE) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        k, v = line.split("=", 1)
                        k, v = k.strip(), v.strip()
                        if k == "token":
                            HELPER_TOKEN = v
                        elif k == "listen_port":
                            LISTEN_PORT = int(v)
        except Exception as e:
            log.error("Config error: %s", e)


def _validate_ip(ip: str) -> bool:
    try:
        ipaddress.ip_address(ip)
        return ip in ALLOWED_SOURCE_IPS
    except ValueError:
        return False


def _validate_port(port) -> bool:
    try:
        return int(port) == ALLOWED_TARGET_PORT
    except (TypeError, ValueError):
        return False


def _ensure_chain():
    """Create TT-SIEM chain if it doesn't exist and add it to INPUT."""
    # Create chain (idempotent)
    subprocess.run(
        ["sudo", "/usr/sbin/iptables", "-N", CHAIN],
        capture_output=True,
    )
    # Add chain to INPUT if not already there
    check = subprocess.run(
        ["sudo", "/usr/sbin/iptables", "-C", "INPUT", "-j", CHAIN],
        capture_output=True,
    )
    if check.returncode != 0:
        subprocess.run(
            ["sudo", "/usr/sbin/iptables", "-I", "INPUT", "-j", CHAIN],
            check=True, capture_output=True,
        )


def _apply_block(source_ip: str, target_port: int, duration_sec: int, incident_id: str) -> bool:
    """Add iptables DROP rule in TT-SIEM chain. Returns True on success."""
    _ensure_chain()
    comment = f"tt-siem-{incident_id[:20]}"
    cmd = [
        "sudo", "/usr/sbin/iptables",
        "-I", CHAIN,
        "-s", source_ip,
        "-p", "tcp", "--dport", str(target_port),
        "-m", "comment", "--comment", comment,
        "-j", "DROP",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0:
        log.info("BLOCK applied: src=%s port=%d incident=%s duration=%ds",
                 source_ip, target_port, incident_id, duration_sec)
        return True
    else:
        log.error("BLOCK failed: %s", result.stderr)
        return False


def _remove_block(source_ip: str, target_port: int, incident_id: str) -> bool:
    """Remove iptables DROP rule from TT-SIEM chain."""
    comment = f"tt-siem-{incident_id[:20]}"
    cmd = [
        "sudo", "/usr/sbin/iptables",
        "-D", CHAIN,
        "-s", source_ip,
        "-p", "tcp", "--dport", str(target_port),
        "-m", "comment", "--comment", comment,
        "-j", "DROP",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0:
        log.info("BLOCK removed: src=%s port=%d incident=%s",
                 source_ip, target_port, incident_id)
        return True
    else:
        log.warning("BLOCK removal returned: %s (may already be removed)", result.stderr)
        return True  # Treat as success — idempotent


# ── Schedule auto-expiry using at(1) ─────────────────────────────────────────
def _schedule_expiry(source_ip: str, target_port: int, duration_sec: int, incident_id: str):
    """Schedule automatic rule removal using 'at' — survives helper restart."""
    comment = f"tt-siem-{incident_id[:20]}"
    at_cmd = (
        f"sudo /usr/sbin/iptables -D {CHAIN} "
        f"-s {source_ip} -p tcp --dport {target_port} "
        f"-m comment --comment {comment} -j DROP"
    )
    delay_min = max(1, duration_sec // 60)
    try:
        proc = subprocess.Popen(
            ["at", f"now + {delay_min} minutes"],
            stdin=subprocess.PIPE,
            capture_output=True,
        )
        proc.communicate(input=at_cmd.encode())
        log.info("Scheduled expiry in %d min for incident %s", delay_min, incident_id)
    except FileNotFoundError:
        log.warning("'at' command not found — expiry will not be automatic")
    except Exception as e:
        log.error("Failed to schedule expiry: %s", e)


# ── HTTP handler ──────────────────────────────────────────────────────────────
class HelperHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        log.debug(format, *args)

    def _send_json(self, code: int, data: dict):
        body = json.dumps(data).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _auth(self) -> bool:
        token = self.headers.get("X-Helper-Token", "")
        return HELPER_TOKEN and token == HELPER_TOKEN

    def do_POST(self):
        if not self._auth():
            self._send_json(401, {"error": "unauthorized"})
            return

        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        try:
            data = json.loads(body)
        except json.JSONDecodeError:
            self._send_json(400, {"error": "bad json"})
            return

        if self.path == "/block":
            self._handle_block(data)
        elif self.path == "/unblock":
            self._handle_unblock(data)
        elif self.path == "/health":
            self._send_json(200, {"ok": True})
        else:
            self._send_json(404, {"error": "not found"})

    def do_GET(self):
        if self.path == "/health":
            self._send_json(200, {"ok": True, "service": "tt-siem-helper"})
        else:
            self._send_json(404, {"error": "not found"})

    def _handle_block(self, data: dict):
        source_ip = data.get("source_ip", "")
        target_port = data.get("target_port", 80)
        duration_sec = int(data.get("duration_sec", 60))
        incident_id = data.get("incident_id", "unknown")

        if not _validate_ip(source_ip):
            log.warning("Block rejected: invalid source IP %s", source_ip)
            self._send_json(403, {"error": f"Source IP {source_ip} not in allowed scope"})
            return

        if not _validate_port(target_port):
            log.warning("Block rejected: invalid port %s", target_port)
            self._send_json(403, {"error": f"Port {target_port} not in allowed scope"})
            return

        duration_sec = min(duration_sec, MAX_DURATION_SEC)

        ok = _apply_block(source_ip, int(target_port), duration_sec, incident_id)
        if ok:
            _schedule_expiry(source_ip, int(target_port), duration_sec, incident_id)
            self._send_json(200, {"ok": True})
        else:
            self._send_json(500, {"ok": False, "error": "iptables command failed"})

    def _handle_unblock(self, data: dict):
        source_ip = data.get("source_ip", "")
        incident_id = data.get("incident_id", "unknown")

        if not _validate_ip(source_ip):
            self._send_json(403, {"error": f"Source IP {source_ip} not in allowed scope"})
            return

        ok = _remove_block(source_ip, ALLOWED_TARGET_PORT, incident_id)
        self._send_json(200, {"ok": ok})


def main():
    _load_config()
    if not HELPER_TOKEN:
        print("ERROR: TT_HELPER_TOKEN environment variable or config token is required", file=sys.stderr)
        sys.exit(1)

    _ensure_chain()
    log.info("Response helper listening on %s:%d", LISTEN_HOST, LISTEN_PORT)

    server = HTTPServer((LISTEN_HOST, LISTEN_PORT), HelperHandler)

    def _shutdown(sig, frame):
        log.info("Shutting down helper")
        server.shutdown()

    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT, _shutdown)

    server.serve_forever()


if __name__ == "__main__":
    main()
