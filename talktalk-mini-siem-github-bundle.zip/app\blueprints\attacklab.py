"""TalkTalk Lab — Mini-SIEM · Attack Lab blueprint"""
import csv
import json
from pathlib import Path
from flask import Blueprint, render_template, current_app
from flask_login import login_required
from flask_wtf.csrf import generate_csrf
from ..db import get_db

bp = Blueprint("attacklab", __name__, url_prefix="/attack-lab")

FAMILY_LABELS = [
    ("normal", "Normal lookup"),
    ("boolean_or", "OR injection"),
    ("boolean_and", "AND injection"),
    ("union", "UNION injection"),
    ("comment_variant", "Comment-separated evasion"),
]


def _load_cases():
    cases_path = current_app.config.get("CASES_CSV")
    if not Path(cases_path).exists():
        # Try evidence zip extract
        alt = Path(
            r"C:\Users\HP\.gemini\antigravity\scratch\talktalk-zip-extract\traffic\cases.csv"
        )
        if alt.exists():
            cases_path = str(alt)
        else:
            return []

    cases = []
    with open(cases_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            cases.append(
                {
                    "case_id": row["case_id"],
                    "label": row["label"],
                    "family": row["family"],
                    "input": row["input"],
                }
            )
    return cases


@bp.route("/")
@login_required
def index():
    db = get_db()
    cases = _load_cases()

    # Runs sorted newest first
    runs = db.execute(
        "SELECT run_id, mode, source, status, case_count, started_utc "
        "FROM runs ORDER BY started_utc DESC LIMIT 20"
    ).fetchall()

    app_state_row = db.execute(
        "SELECT state FROM app_state WHERE id=1"
    ).fetchone()
    app_state = app_state_row["state"] if app_state_row else "unknown"

    lab_host = current_app.config.get("LAB_HOST", "192.168.77.10")
    lab_url = current_app.config.get("LAB_BASE_URL", f"http://{lab_host}/DVWA")

    return render_template(
        "attacklab.html",
        cases=cases,
        cases_json=json.dumps(cases),
        families=FAMILY_LABELS,
        runs=runs,
        app_state=app_state,
        lab_host=lab_host,
        lab_url=lab_url,
    )
