"""
TalkTalk Lab — Mini-SIEM · Application entry point
"""
import sys
import os

# Add project root to path
sys.path.insert(0, os.path.dirname(__file__))

from app import create_app

app = create_app()

if __name__ == "__main__":
    host = os.environ.get("SIEM_HOST", "127.0.0.1")
    port = int(os.environ.get("SIEM_PORT", "8080"))
    debug = os.environ.get("SIEM_DEBUG", "0") == "1"
    print(f"TalkTalk Lab — Mini-SIEM starting on http://{host}:{port}")
    print(f"Fixture mode: {app.config.get('FIXTURE_MODE', False)}")
    app.run(host=host, port=port, debug=debug, threaded=True)
