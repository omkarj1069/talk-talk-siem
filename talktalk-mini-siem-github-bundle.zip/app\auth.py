"""
TalkTalk Lab — Mini-SIEM  ·  Authentication
Simple single-admin login using Flask-Login.
Credentials configured via environment variables, never hard-coded.
"""
import logging
from flask import current_app
from flask_login import LoginManager, UserMixin

log = logging.getLogger(__name__)

login_manager = LoginManager()


class AdminUser(UserMixin):
    """Single fixed admin user — no database user table needed."""
    id = "admin"

    def __init__(self, username):
        self.username = username

    def get_id(self):
        return self.id


def init_login_manager(app):
    login_manager.login_view = "auth.login"
    login_manager.login_message = "Please log in to access the dashboard."
    login_manager.init_app(app)

    # Register auth blueprint
    from .blueprints.auth_bp import bp as auth_bp
    app.register_blueprint(auth_bp)


@login_manager.user_loader
def load_user(user_id):
    if user_id == "admin":
        return AdminUser(current_app.config["ADMIN_USERNAME"])
    return None


def check_credentials(username: str, password: str) -> bool:
    expected_user = current_app.config["ADMIN_USERNAME"]
    expected_pass = current_app.config["ADMIN_PASSWORD"]
    return username == expected_user and password == expected_pass
