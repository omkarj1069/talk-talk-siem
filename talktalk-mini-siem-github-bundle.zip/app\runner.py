"""
TalkTalk Lab — Mini-SIEM · DVWA test runner
Executes a single test case against DVWA, parsing:
- HTTP status code
- Record count from HTML table
- Patch marker (TT_SQLI_MITIGATION_V1)
- Rejection class (tt-input-rejected)
- Stores response evidence (sanitised)
"""
import csv
import hashlib
import json
import logging
import re
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

import requests as http_requests
from requests import Session

log = logging.getLogger(__name__)

PATCH_MARKER = "TT_SQLI_MITIGATION_V1"
REJECTION_CLASS = "tt-input-rejected"
REJECTION_MSG = "Invalid User ID. Enter a whole number."

# Suricata rule SID → name mapping
RULE_NAMES = {
    "1000001": "WEB-ATTACKS SQLi boolean OR pattern",
    "1000002": "WEB-ATTACKS SQLi boolean AND pattern",
    "1000003": "WEB-ATTACKS SQLi UNION SELECT pattern",
}


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _get_dvwa_token(session: Session, base_url: str, timeout: int) -> str:
    resp = session.get(f"{base_url}/login.php", timeout=timeout)
    resp.raise_for_status()
    m = re.search(r'name=["\']user_token["\'][^>]*value=["\']([^"\']+)["\']', resp.text, re.I)
    if not m:
        m = re.search(r'value=["\']([^"\']+)["\'][^>]*name=["\']user_token["\']', resp.text, re.I)
    if not m:
        raise ValueError("DVWA CSRF token not found on login page")
    return m.group(1)


def _dvwa_login(session: Session, base_url: str, user: str, pwd: str, timeout: int) -> bool:
    """Log in to DVWA. Returns True on success."""
    token = _get_dvwa_token(session, base_url, timeout)
    resp = session.post(
        f"{base_url}/login.php",
        data={
            "username": user,
            "password": pwd,
            "Login": "Login",
            "user_token": token,
        },
        timeout=timeout,
        allow_redirects=True,
    )
    return "logout.php" in resp.text


def _count_records(html: str) -> int:
    """Count first_name/last_name result rows in DVWA output."""
    # Each result has "First name:" in a <pre> tag
    return len(re.findall(r"First name:", html, re.I))


def _check_patch_marker(html: str) -> bool:
    return PATCH_MARKER in html


def _check_rejected(html: str) -> bool:
    return REJECTION_CLASS in html or REJECTION_MSG in html


def execute_case(
    run_id: str,
    case: dict,
    cfg: dict,
    db_path: str,
) -> dict:
    """
    Execute one DVWA test case and return the result dict.
    Also writes result to the database.
    """
    case_id = case["case_id"]
    label = case["label"]
    family = case["family"]
    input_val = case["input"]

    base_url = cfg.get("LAB_BASE_URL", "http://192.168.77.10/DVWA")
    timeout = cfg.get("REQUEST_TIMEOUT_SECONDS", 20)
    dvwa_user = cfg.get("DVWA_USER", "admin")
    dvwa_pass = cfg.get("DVWA_PASS", "password")
    alert_window = cfg.get("ALERT_COLLECTION_WINDOW_SECONDS", 10)

    result = {
        "run_id": run_id,
        "case_id": case_id,
        "label": label,
        "family": family,
        "input": input_val,
        "started_utc": _utcnow(),
        "finished_utc": None,
        "http_status": None,
        "response_ms": None,
        "records": None,
        "patch_present": None,
        "input_rejected": None,
        "request_url": None,
        "response_file": None,
        "ids_detected": None,
        "ids_rule_sid": None,
        "ids_rule_name": None,
        "alert_ts": None,
        "ids_observation_complete": False,
        "window_seconds": alert_window,
        "src_ip": "192.168.77.1",
        "error": None,
    }

    session = Session()
    try:
        # Login
        ok = _dvwa_login(session, base_url, dvwa_user, dvwa_pass, timeout)
        if not ok:
            result["error"] = "DVWA login failed — check credentials or session"
            return _save_result(result, db_path)

        # Build URL — never modify the attack payload itself
        params = {
            "id": input_val,
            "Submit": "Submit",
            "tt_run": run_id,
            "tt_case": case_id,
        }
        url = f"{base_url}/vulnerabilities/sqli/"
        from urllib.parse import urlencode
        full_url = f"{url}?{urlencode(params)}"
        result["request_url"] = full_url

        t0 = time.monotonic()
        resp = session.get(url, params=params, timeout=timeout)
        elapsed_ms = (time.monotonic() - t0) * 1000

        result["http_status"] = resp.status_code
        result["response_ms"] = round(elapsed_ms, 2)
        result["finished_utc"] = _utcnow()

        # Parse response — do NOT render raw HTML in dashboard
        html = resp.text
        result["records"] = _count_records(html)
        result["patch_present"] = _check_patch_marker(html)
        result["input_rejected"] = _check_rejected(html)

    except http_requests.exceptions.Timeout:
        result["error"] = "Connection timeout"
        result["finished_utc"] = _utcnow()
    except http_requests.exceptions.ConnectionError as e:
        result["error"] = f"Connection error: {str(e)[:100]}"
        result["finished_utc"] = _utcnow()
    except Exception as e:
        result["error"] = f"Unexpected error: {str(e)[:200]}"
        result["finished_utc"] = _utcnow()
    finally:
        session.close()

    # Wait briefly for IDS alert to arrive
    time.sleep(min(2, alert_window))

    # Look up alert in DB
    from .db import open_db_direct
    conn = open_db_direct(db_path)
    try:
        started = result.get("started_utc", "")
        alert = conn.execute(
            "SELECT * FROM alerts WHERE run_id=? AND case_id=? "
            "UNION "
            "SELECT * FROM alerts WHERE src_ip='192.168.77.1' "
            "AND timestamp_utc >= ? "
            "ORDER BY timestamp_utc DESC LIMIT 1",
            (run_id, case_id, started),
        ).fetchone()
        if alert:
            result["ids_detected"] = True
            result["ids_rule_sid"] = alert["rule_sid"]
            result["ids_rule_name"] = RULE_NAMES.get(
                str(alert["rule_sid"]), alert["rule_name"] or "—"
            )
            result["alert_ts"] = alert["timestamp_utc"]
        else:
            result["ids_detected"] = False
        result["ids_observation_complete"] = True
    finally:
        conn.close()

    return _save_result(result, db_path)


def _save_result(result: dict, db_path: str) -> dict:
    from .db import open_db_direct
    conn = open_db_direct(db_path)
    try:
        conn.execute(
            """INSERT OR REPLACE INTO case_results
               (run_id, case_id, label, family, input,
                started_utc, finished_utc, http_status, response_ms,
                records, patch_present, input_rejected, request_url,
                response_file, ids_detected, ids_rule_sid, error)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                result["run_id"],
                result["case_id"],
                result["label"],
                result["family"],
                result["input"],
                result.get("started_utc"),
                result.get("finished_utc"),
                result.get("http_status"),
                result.get("response_ms"),
                result.get("records"),
                1 if result.get("patch_present") else 0,
                1 if result.get("input_rejected") else 0,
                result.get("request_url"),
                result.get("response_file"),
                1 if result.get("ids_detected") else 0,
                result.get("ids_rule_sid"),
                result.get("error"),
            ),
        )
        conn.commit()
    except Exception as e:
        log.error("Failed to save case result: %s", e)
    finally:
        conn.close()
    return result
