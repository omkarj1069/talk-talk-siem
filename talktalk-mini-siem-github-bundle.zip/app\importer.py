"""
TalkTalk Lab — Mini-SIEM  ·  Historical run importer
Loads the pre-existing baseline and mitigated run data from the ZIP
evidence into the SQLite database on first startup.
Never overwrites existing run records.
"""
import csv
import hashlib
import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path

log = logging.getLogger(__name__)

# Historical run directories (relative to this file's parent's parent, i.e. project root)
_HIST_DIR = Path(__file__).parent.parent / "data" / "historical"

# Fallback: look in the ZIP extract location
_ZIP_TRAFFIC = Path(r"C:\Users\HP\.gemini\antigravity\scratch\talktalk-zip-extract\traffic")

KNOWN_RUNS = {
    "baseline-20261007T165854753Z": {
        "mode": "baseline",
        "source": "historical",
        "dataset_sha256": "B956230B821338CDAA760AD501C1492A7464DF885840F9935256AF17C9CE095B",
    },
    "mitigated-20261007T174547794Z": {
        "mode": "mitigated",
        "source": "historical",
        "dataset_sha256": "B956230B821338CDAA760AD501C1492A7464DF885840F9935256AF17C9CE095B",
    },
}


def _find_run_dir(run_id: str) -> Path | None:
    # Check bundled data directory first
    candidate = _HIST_DIR / run_id
    if candidate.exists():
        return candidate
    # Fallback to ZIP extract
    candidate = _ZIP_TRAFFIC / run_id
    if candidate.exists():
        return candidate
    return None


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def import_historical_runs_if_needed():
    """Called at application startup with app context active."""
    from .db import get_db
    db = get_db()

    for run_id, meta in KNOWN_RUNS.items():
        exists = db.execute(
            "SELECT id FROM runs WHERE run_id=?", (run_id,)
        ).fetchone()
        if exists:
            log.info("Historical run %s already imported, skipping.", run_id)
            continue

        run_dir = _find_run_dir(run_id)
        if run_dir is None:
            log.warning(
                "Historical run directory not found for %s — skipped.", run_id
            )
            continue

        _import_run(db, run_id, run_dir, meta)
        db.commit()
        log.info("Imported historical run %s", run_id)


def _import_run(db, run_id: str, run_dir: Path, meta: dict):
    # Read run.json for started_utc
    run_json_path = run_dir / "run.json"
    started_utc = _utcnow()
    if run_json_path.exists():
        try:
            rj = json.loads(run_json_path.read_text(encoding="utf-8"))
            started_utc = rj.get("started_utc", started_utc)
        except Exception:
            pass

    now = _utcnow()
    db.execute(
        """INSERT OR IGNORE INTO runs
           (run_id, mode, source, started_utc, finished_utc, status,
            dataset_sha256, auto_response, case_count, notes, created_utc)
           VALUES (?,?,?,?,?,?,?,0,24,'Historical run imported from evidence archive',?)""",
        (
            run_id,
            meta["mode"],
            meta["source"],
            started_utc,
            started_utc,        # finished = same as started for historical
            "complete",
            meta.get("dataset_sha256"),
            now,
        ),
    )

    # Read responses.csv
    resp_path = run_dir / "responses.csv"
    if not resp_path.exists():
        log.warning("responses.csv not found in %s", run_dir)
        return

    with open(resp_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Determine IDS detection from known facts
            case_id = row.get("case_id", "")
            label = row.get("label", "")
            ids_detected = _ids_detected_for(case_id, meta["mode"])

            patch_present = _parse_bool(row.get("patch_present"))
            input_rejected = _parse_bool(row.get("input_rejected"))

            db.execute(
                """INSERT OR IGNORE INTO case_results
                   (run_id, case_id, label, family, input,
                    started_utc, finished_utc, http_status, response_ms,
                    records, patch_present, input_rejected, request_url,
                    response_file, ids_detected)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    run_id,
                    case_id,
                    label,
                    row.get("family", ""),
                    row.get("input", ""),
                    row.get("started_utc"),
                    row.get("finished_utc"),
                    _int_or_none(row.get("http_status")),
                    _float_or_none(row.get("response_ms")),
                    _int_or_none(row.get("records")),
                    patch_present,
                    input_rejected,
                    row.get("request_url"),
                    row.get("response_file"),
                    ids_detected,
                ),
            )


def _ids_detected_for(case_id: str, mode: str) -> int | None:
    """
    Known IDS results from the verified experiment.
    A01-A03: detected (SID 1000001 — boolean OR)
    A04-A06: detected (SID 1000002 — boolean AND)
    A07-A09: detected (SID 1000003 — UNION SELECT)
    A10-A12: missed
    B01-B12: not attacked (TN context — no alert expected)
    """
    if case_id.startswith("B"):
        return 0   # TN — no alert (correct)
    attack_num = int(case_id[1:]) if case_id[1:].isdigit() else 0
    if 1 <= attack_num <= 9:
        return 1   # TP
    if 10 <= attack_num <= 12:
        return 0   # FN — missed
    return None


def _parse_bool(val) -> int | None:
    if val is None:
        return None
    if isinstance(val, bool):
        return 1 if val else 0
    if str(val).strip().lower() in ("true", "1", "yes"):
        return 1
    if str(val).strip().lower() in ("false", "0", "no"):
        return 0
    return None


def _int_or_none(val):
    try:
        return int(val)
    except (TypeError, ValueError):
        return None


def _float_or_none(val):
    try:
        return float(val)
    except (TypeError, ValueError):
        return None
