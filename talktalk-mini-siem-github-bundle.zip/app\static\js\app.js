"""
TalkTalk Lab — Mini-SIEM · JavaScript utilities
Shared frontend helpers (CSRF, encoding, polling).
No CDN dependencies.
"""
