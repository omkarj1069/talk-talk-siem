# TalkTalk Lab — Mini-SIEM API & Integration Specification

This document defines the backend REST API endpoints, schemas, and integration points for connecting the frontend dashboard with the backend SIEM server.

---

## 1. System Overview & Base URL
- **Local Dev Server**: `http://127.0.0.1:8080` (or `http://localhost:5000`)
- **Lab Target (Ubuntu)**: `http://192.168.77.10/DVWA`
- **Request Source (Windows)**: `192.168.77.1`
- **Content-Type**: `application/json`

---

## 2. API Endpoints

### 2.1 Get System Metrics & Status
- **Method**: `GET`
- **Endpoint**: `/api/status`
- **Description**: Returns live dashboard counts, active blocks, and auto-response switch status.
- **Response** (`200 OK`):
```json
{
  "request_count": 24,
  "alert_count": 9,
  "incident_count": 1,
  "active_blocks": 0,
  "auto_response": false
}
```

---

### 2.2 Red Team: Execute Single Test Case
- **Method**: `POST`
- **Endpoint**: `/api/run/single`
- **Headers**: `Content-Type: application/json`, `X-CSRFToken: <token>`
- **Request Payload**:
```json
{
  "case_id": "A01"
}
```
- **Response** (`200 OK`):
```json
{
  "run_id": "live-20261024-a1b2c3",
  "case_id": "A01",
  "label": "attack",
  "family": "boolean_or",
  "input": "1' OR '1'='1",
  "http_status": 200,
  "response_ms": 18.2,
  "records": 5,
  "patch_present": false,
  "input_rejected": false,
  "ids_detected": true,
  "ids_rule_sid": "1000001",
  "ids_rule_name": "WEB-ATTACKS SQLi boolean OR pattern",
  "request_url": "http://192.168.77.10/DVWA/vulnerabilities/sqli/?id=1'%20OR%20'1'%3D'1&Submit=Submit&tt_run=live-20261024-a1b2c3&tt_case=A01",
  "src_ip": "192.168.77.1"
}
```

---

### 2.3 Red Team: Execute All 24 Cases
- **Method**: `POST`
- **Endpoint**: `/api/run/all`
- **Headers**: `Content-Type: application/json`, `X-CSRFToken: <token>`
- **Request Payload**: `{}`
- **Response** (`200 OK`):
```json
{
  "run_id": "live-20261024-d4e5f6",
  "status": "running",
  "total": 24
}
```

---

### 2.4 Poll Run Progress
- **Method**: `GET`
- **Endpoint**: `/api/run/status/{run_id}`
- **Response** (`200 OK`):
```json
{
  "run_id": "live-20261024-d4e5f6",
  "status": "running",
  "completed": 12,
  "total": 24,
  "current_case": "A01",
  "last_result": {
    "case_id": "B12",
    "http_status": 200,
    "records": 0
  }
}
```

---

### 2.5 Cancel Active Run
- **Method**: `POST`
- **Endpoint**: `/api/run/cancel/{run_id}`
- **Response** (`200 OK`):
```json
{
  "ok": true
}
```

---

### 2.6 Toggle Automated Defense Response
- **Method**: `POST`
- **Endpoint**: `/api/settings/auto_response`
- **Request Payload**:
```json
{
  "enabled": true
}
```
- **Response** (`200 OK`):
```json
{
  "ok": true,
  "auto_response": true
}
```

---

### 2.7 Blue Team: Trigger Firewall Block
- **Method**: `POST`
- **Endpoint**: `/api/response/block`
- **Request Payload**:
```json
{
  "incident_id": "INC-001"
}
```
- **Response** (`200 OK`):
```json
{
  "ok": true,
  "detail": "blocked"
}
```

---

### 2.8 Blue Team: Remove Active Block
- **Method**: `POST`
- **Endpoint**: `/api/response/unblock`
- **Request Payload**:
```json
{
  "incident_id": "INC-001",
  "source_ip": "192.168.77.1"
}
```
- **Response** (`200 OK`):
```json
{
  "ok": true,
  "verification": "access_restored"
}
```

---

### 2.9 Collector Ingestion (Ubuntu &rarr; Windows)
- **Method**: `POST`
- **Endpoint**: `/api/collector/ingest`
- **Headers**: `X-Collector-Token: <token>`
- **Request Payload**:
```json
{
  "events": [
    {
      "source": "suricata",
      "event_type": "alert",
      "timestamp_utc": "2026-10-24T10:14:21.000Z",
      "src_ip": "192.168.77.1",
      "dst_ip": "192.168.77.10",
      "dst_port": 80,
      "proto": "TCP",
      "rule_sid": "1000001",
      "rule_name": "TT LAB SQLi quoted OR pattern",
      "severity": 1,
      "http_url": "/DVWA/vulnerabilities/sqli/?id=1'%20OR%20'1'%3D'1",
      "http_method": "GET"
    }
  ]
}
```

---

## 3. Frontend Architecture & Folder Structure
```
talktalk-mini-siem/
├── frontend/                  <-- Pure static frontend (Open in any browser!)
│   ├── index.html             (01 / Overview)
│   ├── attack-lab.html        (02 / Red Team Simulation)
│   ├── incidents.html         (03 / Blue Team Defense)
│   ├── results.html           (04 / Before & After)
│   ├── css/
│   │   └── main.css           (Navy sidebar, rounded cards, responsive styles)
│   └── js/
│       ├── app.js             (Fetch handlers & CSRF utilities)
│       └── chart.umd.min.js   (Locally bundled Chart.js)
│
├── app/                       <-- Python Flask Backend & Dynamic Templates
│   ├── blueprints/
│   │   ├── api.py             (All REST endpoints above)
│   │   ├── overview.py
│   │   ├── attacklab.py
│   │   ├── incidents.py
│   │   └── results.py
│   ├── static/                (Static CSS/JS used by Flask)
│   └── templates/             (Jinja2 dynamic server-rendered pages)
│
├── ubuntu/                    <-- Ubuntu sensor & response scripts
│   ├── tt-collector.py        (Apache & Suricata EVE log forwarder)
│   ├── tt-response-helper.py  (Restricted iptables TT-SIEM manager)
│   └── install-ubuntu.sh      (Systemd service installer)
│
├── data/                      <-- Datasets & historical evidence
│   ├── cases.csv              (24 verified test cases: 12 benign, 12 attack)
│   └── historical/            (Baseline & mitigated run evidence)
│
├── config.py                  (Central configuration)
└── run.py                     (Python application entry point)
```
