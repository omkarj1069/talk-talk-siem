# TalkTalk Lab — Mini-SIEM Implementation Checklist

## Phase Weights (total 100%)
| Phase | Weight | Description |
|-------|--------|-------------|
| 1 | 5% | Inspect, scaffold, project records |
| 2 | 20% | Four-screen UI (reference image match) |
| 3 | 12% | Event collection from Apache + Suricata |
| 4 | 18% | Test execution, DVWA integration, correlation |
| 5 | 12% | Incident grouping + automated response |
| 6 | 5% | Controlled application switching |
| 7 | 10% | Comparison, metrics, reports export |
| 8 | 8% | Security, auth, CSRF, reliability |
| 9 | 7% | Automated tests |
| 10 | 3% | Delivery docs, runbook |

---

## Phase 1 — Scaffold (5%)
- [x] Workspace inspected, runtimes confirmed (Python 3.10.4, Flask 3.1.3)
- [x] Packages installed (requests, apscheduler, watchdog, flask-login, flask-wtf)
- [x] cases.csv schema read and validated
- [x] baseline + mitigated responses.csv schemas read
- [x] run-baseline.ps1 logic reviewed
- [x] Project directory structure created
- [x] IMPLEMENTATION_CHECKLIST.md created
- [ ] PROJECT_STATE.md created
- [ ] HANDOFF.md created
- [ ] .gitignore created
- [ ] config.py with safe defaults
- [ ] Database module (SQLite, migrations)
- [ ] Logging setup
- [ ] Fixture mode scaffolded
- [ ] Test project scaffolded

## Phase 2 — Four-Screen UI (20%)
### Layout / Nav
- [ ] Navy sidebar, blue selected state
- [ ] Pale background, white rounded cards
- [ ] Typography, spacing, icons, badges
- [ ] All four pages navigable

### Overview (Page 1)
- [ ] Service status cards (Ubuntu/Apache/Suricata) — unknown/stale states
- [ ] Metric cards: requests, alerts, incidents, active blocks
- [ ] Activity chart (30-min window, normal/attack bars)
- [ ] Recent events table with links
- [ ] Application state indicator (original/patched/unknown)
- [ ] Auto-response state + collector freshness
- [ ] Time window/run filter

### Attack Lab (Page 2)
- [ ] Test case selector (Normal/OR/AND/UNION/Comment-variant)
- [ ] Shows actual input from dataset
- [ ] Run test + Run 24 cases buttons
- [ ] Progress display, cancel, error states
- [ ] Returned records display
- [ ] HTTP status / connection error display
- [ ] Rejection + patch-marker indicators
- [ ] IDS alerts or "none observed" message
- [ ] DVWA link
- [ ] Saved run history

### Incidents (Page 3)
- [ ] Incident list: severity, status, source, target, timestamps
- [ ] Related requests/rules/Apache evidence
- [ ] Timeline + response details
- [ ] Acknowledge/Resolve actions
- [ ] Auto-response switch
- [ ] Manual unblock
- [ ] Report download

### Results (Page 4)
- [ ] Run selection (baseline / patched)
- [ ] Per-case comparison table
- [ ] Benign preservation indicators
- [ ] Attack-input rejection indicators
- [ ] IDS TP/FN/TN/FP + derived metrics
- [ ] Automated response experiment results
- [ ] Before/after chart
- [ ] Evidence completeness indicators
- [ ] DEMO/FIXTURE badge when in fixture mode

## Phase 3 — Event Collection (12%)
- [ ] Apache access.log reader (no modification)
- [ ] Suricata eve.json reader (no modification)
- [ ] Timestamp normalization (UTC stored, local displayed)
- [ ] Durable read checkpoints
- [ ] Partial line handling
- [ ] Log rotation handling
- [ ] Restart recovery
- [ ] Deduplication
- [ ] Bounded buffering
- [ ] Collector failure exposure in UI
- [ ] Service status collection (hash verification)
- [ ] Live dashboard polling endpoint (/api/status)
- [ ] Idempotent ingestion

## Phase 4 — Test Execution & Correlation (18%)
- [ ] Import + validate 24-case dataset (hash check)
- [ ] DVWA login with CSRF token
- [ ] Cookie/session-expiry detection
- [ ] Credentials server-side only
- [ ] Destination restriction to lab target
- [ ] Unique run/case identifiers in URL params
- [ ] Response parsing (records, rejection, patch marker)
- [ ] Evidence preservation
- [ ] No raw HTML rendering of DVWA responses
- [ ] Run/alert correlation by run+case ID
- [ ] Delayed event window
- [ ] "No alert observed" vs "capture incomplete"
- [ ] Store dataset/rule/app hashes per run
- [ ] Concurrent run prevention
- [ ] Cancel support

## Phase 5 — Incidents & Response (12%)
- [ ] SQLi alert grouping by source + time window
- [ ] Deduplication of alerts/actions
- [ ] Configurable threshold + duration
- [ ] Auto-response OFF by default
- [ ] Scope: 192.168.77.1 → 192.168.77.10:80 only
- [ ] Dedicated iptables chain (TT-SIEM)
- [ ] Preserve SSH/collector/dashboard access
- [ ] States: requested/applied/verified/failed/expired/manually_removed
- [ ] Fresh-connection verification after block
- [ ] Failure wording: timeout vs refusal vs other
- [ ] Auto-expiry via cron (survives dashboard stop)
- [ ] Restart reconciliation
- [ ] Safe manual unblock command
- [ ] Audit log of all response actions
- [ ] UI: timeline, expiry countdown, verification evidence

## Phase 6 — Application Switching (5%)
- [ ] operator-switch.sh command (Ubuntu side)
- [ ] Hash verification before + after install
- [ ] Preserve file ownership/permissions
- [ ] PHP syntax validation
- [ ] Block during active experiment
- [ ] Report actual application state to dashboard
- [ ] No arbitrary file-write feature

## Phase 7 — Comparison & Reports (10%)
- [ ] Three experiment modes: A/B/C clearly separated
- [ ] Case-level IDS confusion matrix
- [ ] Precision, recall, FPR, accuracy
- [ ] Benign record-count preservation
- [ ] Explicit attack-input rejection
- [ ] Block verification results
- [ ] Detection/response timings with definitions
- [ ] Undefined metrics flagged
- [ ] HTML incident report export
- [ ] JSON incident evidence export
- [ ] CSV case results export
- [ ] Experiment summary with hashes + limitations
- [ ] Historical imported runs separated from live

## Phase 8 — Security & Reliability (8%)
- [ ] Dashboard authentication (Flask-Login)
- [ ] CSRF protection (Flask-WTF)
- [ ] Output encoding for displayed inputs/logs
- [ ] Secrets out of source/reports
- [ ] Helper privilege restriction
- [ ] Bounded request sizes + execution time
- [ ] Service outage handling (no fabricated success)
- [ ] Bounded log/evidence storage
- [ ] Local static assets (no CDN)
- [ ] No scanning external systems

## Phase 9 — Tests (7%)
- [ ] Log parsing unit tests
- [ ] Deduplication tests
- [ ] Log rotation / recovery tests
- [ ] Dataset validation tests
- [ ] Response parsing tests (records, rejected, patch)
- [ ] Correlation tests
- [ ] Incident threshold tests
- [ ] Response scope validation tests
- [ ] Expiry tests
- [ ] Metrics calculation tests
- [ ] Auth tests
- [ ] Input encoding tests

## Phase 10 — Delivery (3%)
- [ ] Installation instructions
- [ ] Start/stop/health-check/cleanup scripts
- [ ] Switch commands documented
- [ ] Architecture + data-flow document
- [ ] Professor demonstration runbook
- [ ] Known limitations listed
- [ ] Final feature checklist

---

## Missing Inputs (Cannot Safely Infer)
- Git repository URL — **REQUIRED before Git push steps**
- Ubuntu SSH credentials — **REQUIRED for live collector/response**

## Confirmed Available
- Python 3.10.4, Flask 3.1.3, SQLite (stdlib)
- cases.csv with 24 cases (hash verified in run.json)
- baseline-20261007T165854753Z/responses.csv (24 rows)
- mitigated-20261007T174547794Z/responses.csv (24 rows, patch_present/input_rejected)
- run-baseline.ps1 (DVWA login + CSRF + request runner pattern)
- Project_State.md with verified experiment facts
