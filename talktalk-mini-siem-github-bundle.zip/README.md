# TalkTalk Lab — Mini-SIEM (Cybersecurity Attack Simulation & Automated Response)

A lightweight SIEM and automated response dashboard built for evaluating SQL Injection attacks against DVWA, monitoring Suricata IDS detections, and enforcing automated firewall containment.

![Overview](frontend/css/main.css)

---

## 🚀 Quick Start for Frontend Developers
If you are developing or testing the frontend:
1. Open the `frontend/` directory.
2. Double-click `frontend/index.html` in Chrome, Firefox, or Edge.
3. No build tools, Node.js, or internet connection required! All CSS and Chart.js libraries are locally bundled.
4. Review `API_SPECIFICATION.md` for JSON request/response formats to connect buttons to the backend.

---

## 🛠️ Quick Start for Backend Integration (Flask)
1. Ensure Python 3.10+ is installed.
2. Install dependencies:
   ```bash
   pip install flask flask-login flask-wtf requests apscheduler watchdog
   ```
3. Run the development server:
   ```bash
   python run.py
   ```
4. Access the dashboard at `http://127.0.0.1:8080/`. Default login credentials:
   - **Username**: `admin`
   - **Password**: `talktalk-lab`

---

## 📁 Repository Structure
- `frontend/` — Standalone static HTML/CSS/JS files ready for frontend inspection & live servers.
- `app/` — Dynamic backend application (templates, blueprints, database).
- `ubuntu/` — Lightweight collector (`tt-collector.py`) and response helper (`tt-response-helper.py`) for the victim VM.
- `data/` — 24-case dataset (`cases.csv`) and historical test runs.
- `API_SPECIFICATION.md` — Detailed endpoint documentation.

---

## 🔒 Security Scope & Ethics
- Scoped strictly to the isolated laboratory network (`192.168.77.0/24`).
- All requests target the project VM (`192.168.77.10`).
- No public scanning or external attacks.
