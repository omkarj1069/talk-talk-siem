"""
TalkTalk Lab — Mini-SIEM  ·  Auth blueprint
Login / logout views.
"""
from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_user, logout_user, login_required
from ..auth import AdminUser, check_credentials

bp = Blueprint("auth", __name__, url_prefix="/auth")


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        if check_credentials(username, password):
            user = AdminUser(username)
            login_user(user, remember=False)
            next_page = request.args.get("next") or url_for("overview.index")
            # SSRF protection: only allow relative next URLs
            if next_page.startswith("http"):
                next_page = url_for("overview.index")
            return redirect(next_page)
        flash("Invalid credentials.", "danger")
    return render_template("login.html")


@bp.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("auth.login"))
