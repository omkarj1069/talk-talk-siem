#!/usr/bin/env python3
"""
TalkTalk Lab — Mini-SIEM · Ubuntu Collector
Reads Apache and Suricata logs, forwards events to the Windows dashboard
via HTTP POST.  Designed to run on Ubuntu (192.168.77.10).

Usage:
    python3 tt-collector.py --config /etc/tt-siem/collector.conf

Reads logs using minimum necessary permissions (add user to adm group).
Never modifies log files.  Uses durable byte-offset checkpoints.
"""
import argparse
import hashlib
import json
import logging
import os
import re
import signal
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import requests

# ── Configuration defaults ────────────────────────────────────────────────────
DEFAULTS = {
    "apache_log":         "/var/log/apache2/access.log",
    "suricata_eve":       "/var/log/suricata/eve.json",
    "checkpoint_file":    "/var/lib/tt-siem/collector.checkpoint.json",
    "backend_url":        "http://192.168.77.1:8080/api/collector/ingest",
    "collector_token":    "",                 # REQUIRED — set in config file
    "flush_interval_sec": 5,
    "max_batch_size":     50,
    "request_timeout":    15,
    "heartbeat_interval": 30,
    "log_level":          "INFO",
}

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s tt-collector %(message)s",
)
log = logging.getLogger("tt-collector")

_running = True


def _signal_handler(sig, frame):
    global _running
    log.info("Shutting down on signal %s", sig)
    _running = False


signal.signal(signal.SIGTERM, _signal_handler)
signal.signal(signal.SIGINT, _signal_handler)


# ── Checkpointing ─────────────────────────────────────────────────────────────
def load_checkpoint(path: str) -> dict:
    try:
        with open(path) as f:
            return json.load(f)
    except FileNotFoundError:
        return {}
    except Exception as e:
        log.warning("Failed to read checkpoint: %s", e)
        return {}


def save_checkpoint(path: str, data: dict):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f)
    os.replace(tmp, path)


# ── Apache log reader ─────────────────────────────────────────────────────────
APACHE_RE = re.compile(
    r'(?P<ip>\S+) \S+ \S+ \[(?P<ts>[^\]]+)\] '
    r'"(?P<method>\S+) (?P<path>[^"]+) HTTP/[^"]+" '
    r'(?P<status>\d+) \S+'
)
SQLI_PATH = "/DVWA/vulnerabilities/sqli/"


def _parse_apache_ts(ts_str: str) -> str:
    """Convert Apache timestamp to ISO-8601 UTC string."""
    try:
        dt = datetime.strptime(ts_str, "%d/%b/%Y:%H:%M:%S %z")
        return dt.astimezone(timezone.utc).isoformat()
    except Exception:
        return datetime.now(timezone.utc).isoformat()


def _dedup_key(source: str, ts: str, data: str) -> str:
    return hashlib.sha256(f"{source}:{ts}:{data}".encode()).hexdigest()[:32]


def read_apache_lines(log_path: str, checkpoint: dict) -> tuple[list, int]:
    """Read new lines from Apache access.log since last checkpoint.
    Returns (events, new_byte_offset)."""
    key = f"apache:{log_path}"
    offset = checkpoint.get(key, {}).get("byte_offset", 0)
    saved_inode = checkpoint.get(key, {}).get("inode")

    events = []
    try:
        stat = os.stat(log_path)
        current_inode = stat.st_ino

        # Detect log rotation
        if saved_inode and current_inode != saved_inode:
            log.info("Log rotation detected for %s — resetting offset", log_path)
            offset = 0

        with open(log_path, "rb") as f:
            f.seek(offset)
            new_offset = offset
            for raw_line in f:
                new_offset += len(raw_line)
                line = raw_line.decode("utf-8", errors="replace").rstrip()
                if not line:
                    continue
                m = APACHE_RE.match(line)
                if not m:
                    continue

                src_ip = m.group("ip")
                ts_raw = m.group("ts")
                method = m.group("method")
                path = m.group("path")
                status = m.group("status")

                # Only report SQLI endpoint hits
                if SQLI_PATH not in path:
                    continue

                ts_utc = _parse_apache_ts(ts_raw)
                dedup = _dedup_key("apache", ts_utc, line)

                # Extract run/case from URL params
                run_id = case_id = None
                mm = re.search(r"tt_run=([^&\s]+)", path)
                if mm:
                    run_id = mm.group(1)
                mm = re.search(r"tt_case=([^&\s]+)", path)
                if mm:
                    case_id = mm.group(1)

                events.append({
                    "source": "apache",
                    "event_type": "http_request",
                    "timestamp_utc": ts_utc,
                    "timestamp_raw": ts_raw,
                    "src_ip": src_ip,
                    "method": method,
                    "path": path,
                    "http_status": status,
                    "run_id": run_id,
                    "case_id": case_id,
                    "dedup_key": dedup,
                })

        return events, new_offset, current_inode

    except FileNotFoundError:
        log.warning("Apache log not found: %s", log_path)
        return [], offset, None
    except PermissionError:
        log.error("Permission denied reading %s — check group membership", log_path)
        return [], offset, None


# ── Suricata eve.json reader ───────────────────────────────────────────────────
def read_suricata_lines(eve_path: str, checkpoint: dict) -> tuple[list, int]:
    """Read new alert events from Suricata eve.json."""
    key = f"suricata:{eve_path}"
    offset = checkpoint.get(key, {}).get("byte_offset", 0)
    saved_inode = checkpoint.get(key, {}).get("inode")

    events = []
    try:
        stat = os.stat(eve_path)
        current_inode = stat.st_ino

        if saved_inode and current_inode != saved_inode:
            log.info("Log rotation detected for %s — resetting offset", eve_path)
            offset = 0

        with open(eve_path, "rb") as f:
            f.seek(offset)
            new_offset = offset
            partial = b""

            chunk = f.read(65536)
            while chunk:
                new_offset += len(chunk)
                lines = (partial + chunk).split(b"\n")
                partial = lines[-1]
                for raw_line in lines[:-1]:
                    line = raw_line.decode("utf-8", errors="replace").strip()
                    if not line:
                        continue
                    try:
                        ev = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    if ev.get("event_type") != "alert":
                        continue

                    ts_utc = ev.get("timestamp", "")
                    # Normalise timestamp
                    try:
                        dt = datetime.fromisoformat(ts_utc.replace("Z", "+00:00"))
                        ts_utc = dt.astimezone(timezone.utc).isoformat()
                    except Exception:
                        ts_utc = datetime.now(timezone.utc).isoformat()

                    alert = ev.get("alert", {})
                    http = ev.get("http", {})
                    dedup = _dedup_key("suricata", ts_utc, line[:200])

                    events.append({
                        "source": "suricata",
                        "event_type": "alert",
                        "timestamp_utc": ts_utc,
                        "timestamp_raw": ev.get("timestamp"),
                        "src_ip": ev.get("src_ip"),
                        "dst_ip": ev.get("dest_ip"),
                        "dst_port": ev.get("dest_port"),
                        "proto": ev.get("proto"),
                        "rule_sid": str(alert.get("signature_id", "")),
                        "rule_name": alert.get("signature", ""),
                        "severity": alert.get("severity", 2),
                        "http_url": http.get("url"),
                        "http_method": http.get("http_method"),
                        "dedup_key": dedup,
                    })
                chunk = f.read(65536)

        return events, new_offset, current_inode

    except FileNotFoundError:
        log.warning("Suricata eve.json not found: %s", eve_path)
        return [], offset, None
    except PermissionError:
        log.error("Permission denied reading %s", eve_path)
        return [], offset, None


# ── Sender ────────────────────────────────────────────────────────────────────
def send_events(events: list, cfg: dict) -> bool:
    if not events:
        return True
    try:
        resp = requests.post(
            cfg["backend_url"],
            json={"events": events},
            headers={"X-Collector-Token": cfg["collector_token"]},
            timeout=cfg["request_timeout"],
        )
        if resp.status_code == 200:
            result = resp.json()
            log.debug("Sent %d events; accepted=%s skipped=%s",
                      len(events), result.get("accepted"), result.get("skipped"))
            return True
        else:
            log.warning("Backend returned HTTP %d: %s", resp.status_code, resp.text[:200])
            return False
    except requests.exceptions.Timeout:
        log.warning("Backend request timed out")
        return False
    except requests.exceptions.ConnectionError:
        log.warning("Cannot reach backend — buffering events")
        return False
    except Exception as e:
        log.error("Unexpected send error: %s", e)
        return False


# ── Main loop ──────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="TalkTalk Mini-SIEM collector")
    parser.add_argument("--config", default="/etc/tt-siem/collector.conf")
    parser.add_argument("--backend-url", default="")
    parser.add_argument("--token", default="")
    args = parser.parse_args()

    cfg = dict(DEFAULTS)

    # Load config file
    if Path(args.config).exists():
        try:
            with open(args.config) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        k, v = line.split("=", 1)
                        cfg[k.strip()] = v.strip()
        except Exception as e:
            log.error("Config file error: %s", e)

    if args.backend_url:
        cfg["backend_url"] = args.backend_url
    if args.token:
        cfg["collector_token"] = args.token

    if not cfg["collector_token"]:
        log.error("collector_token is required — set in config or --token")
        sys.exit(1)

    logging.getLogger().setLevel(cfg.get("log_level", "INFO"))

    checkpoint_path = cfg["checkpoint_file"]
    checkpoint = load_checkpoint(checkpoint_path)

    buffer = []  # Events buffered during backend outage
    last_heartbeat = 0

    log.info("Collector started. Backend: %s", cfg["backend_url"])

    while _running:
        # Read new events
        apache_evs, a_offset, a_inode = read_apache_lines(
            cfg["apache_log"], checkpoint
        )
        suricata_evs, s_offset, s_inode = read_suricata_lines(
            cfg["suricata_eve"], checkpoint
        )

        new_events = apache_evs + suricata_evs
        buffer.extend(new_events)

        # Send in batches
        while buffer:
            batch = buffer[:int(cfg["max_batch_size"])]
            ok = send_events(batch, cfg)
            if ok:
                buffer = buffer[len(batch):]
                # Update checkpoint only after successful send
                if a_inode is not None:
                    checkpoint[f"apache:{cfg['apache_log']}"] = {
                        "byte_offset": a_offset,
                        "inode": a_inode,
                    }
                if s_inode is not None:
                    checkpoint[f"suricata:{cfg['suricata_eve']}"] = {
                        "byte_offset": s_offset,
                        "inode": s_inode,
                    }
                save_checkpoint(checkpoint_path, checkpoint)
            else:
                # Buffer overflow protection — discard oldest
                if len(buffer) > 1000:
                    log.warning("Buffer overflow — discarding %d old events", len(buffer) - 500)
                    buffer = buffer[-500:]
                break

        # Heartbeat
        now = time.time()
        if now - last_heartbeat > int(cfg["heartbeat_interval"]):
            send_events([], cfg)  # Empty send to update collector_fresh_utc
            last_heartbeat = now

        time.sleep(float(cfg["flush_interval_sec"]))

    log.info("Collector stopped.")


if __name__ == "__main__":
    main()
