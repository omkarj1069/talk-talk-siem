"""TalkTalk Lab — Mini-SIEM · Incidents blueprint"""
import json
from datetime import datetime, timezone
from flask import Blueprint, render_template, current_app, send_file, abort
from flask_login import login_required
from ..db import get_db
from io import BytesIO

bp = Blueprint("incidents", __name__, url_prefix="/incidents")


def _utc_to_str(utc_str: str) -> str:
    if not utc_str:
        return "—"
    try:
        dt = datetime.fromisoformat(utc_str.replace("Z", "+00:00"))
        return dt.astimezone().strftime("%H:%M:%S")
    except Exception:
        return utc_str[:19]


def _build_timeline(incident, response_action):
    timeline = []

    timeline.append(
        {
            "time": _utc_to_str(incident["first_seen_utc"]),
            "title": "Attack detected",
            "detail": f"Suricata alert — repeated SQL injection from {incident['source_ip']}",
            "dot_class": "red",
        }
    )

    timeline.append(
        {
            "time": _utc_to_str(incident["created_utc"]),
            "title": "Incident created",
            "detail": f"{incident['incident_id']} opened automatically",
            "dot_class": "blue",
        }
    )

    if response_action:
        if response_action["requested_utc"]:
            timeline.append(
                {
                    "time": _utc_to_str(response_action["requested_utc"]),
                    "title": "Block requested",
                    "detail": f"Firewall rule requested to block {response_action['source_ip']}",
                    "dot_class": "amber",
                }
            )
        if response_action["applied_utc"]:
            timeline.append(
                {
                    "time": _utc_to_str(response_action["applied_utc"]),
                    "title": "Block applied",
                    "detail": f"iptables rule added (chain {current_app.config.get('BLOCK_CHAIN','TT-SIEM')})",
                    "dot_class": "green",
                }
            )
        if response_action["verified_utc"]:
            verification = response_action["verification"] or "unknown"
            timeline.append(
                {
                    "time": _utc_to_str(response_action["verified_utc"]),
                    "title": "Web-service block verified",
                    "detail": f"Connection attempt from {response_action['source_ip']} — {verification}",
                    "dot_class": "green",
                }
            )
        if response_action["expires_utc"] and response_action["status"] not in (
            "expired",
            "manually_removed",
        ):
            timeline.append(
                {
                    "time": _utc_to_str(response_action["expires_utc"]),
                    "title": "Automatic unblock scheduled",
                    "detail": f"Block will expire after {(response_action['duration_sec'] or 60)//60} min",
                    "dot_class": "amber",
                }
            )
        if response_action["removed_utc"]:
            timeline.append(
                {
                    "time": _utc_to_str(response_action["removed_utc"]),
                    "title": "Block removed",
                    "detail": response_action["status"],
                    "dot_class": "grey",
                }
            )

    return timeline


@bp.route("/")
@login_required
def index():
    db = get_db()

    incidents_raw = db.execute(
        "SELECT * FROM incidents ORDER BY created_utc DESC LIMIT 50"
    ).fetchall()

    incidents_data = []
    for inc in incidents_raw:
        inc_id = inc["incident_id"]

        # Response action
        ra = db.execute(
            "SELECT * FROM response_actions WHERE incident_id=? ORDER BY created_utc DESC LIMIT 1",
            (inc_id,),
        ).fetchone()

        # Related alerts
        alerts = db.execute(
            "SELECT * FROM alerts WHERE "
            "src_ip=? AND timestamp_utc >= ? AND timestamp_utc <= ? "
            "ORDER BY timestamp_utc ASC LIMIT 20",
            (inc["source_ip"], inc["first_seen_utc"], inc["last_seen_utc"]),
        ).fetchall()

        timeline = _build_timeline(inc, ra)

        incidents_data.append(
            {
                "incident_id": inc_id,
                "severity": inc["severity"],
                "status": inc["status"],
                "source_ip": inc["source_ip"],
                "first_seen_utc": inc["first_seen_utc"],
                "last_seen_utc": inc["last_seen_utc"],
                "created_utc": inc["created_utc"],
                "alert_count": inc["alert_count"],
                "response_action": dict(ra) if ra else None,
                "alerts": [dict(a) for a in alerts],
                "timeline": timeline,
            }
        )

    active_block = db.execute(
        "SELECT id FROM response_actions WHERE status IN ('applied','verified') LIMIT 1"
    ).fetchone()

    ar_row = db.execute(
        "SELECT value FROM siem_settings WHERE key='auto_response'"
    ).fetchone()
    auto_response = ar_row and ar_row[0] == "1"

    cfg = current_app.config
    return render_template(
        "incidents.html",
        incidents=incidents_data,
        active_block=active_block is not None,
        auto_response=auto_response,
        threshold=cfg.get("INCIDENT_THRESHOLD", 3),
        window_seconds=cfg.get("INCIDENT_WINDOW_SECONDS", 60),
    )


@bp.route("/<incident_id>/evidence")
@login_required
def view_evidence(incident_id):
    db = get_db()
    inc = db.execute(
        "SELECT * FROM incidents WHERE incident_id=?", (incident_id,)
    ).fetchone()
    if not inc:
        abort(404)
    alerts = db.execute(
        "SELECT * FROM alerts WHERE src_ip=? AND timestamp_utc >= ? AND timestamp_utc <= ?",
        (inc["source_ip"], inc["first_seen_utc"], inc["last_seen_utc"]),
    ).fetchall()
    ra = db.execute(
        "SELECT * FROM response_actions WHERE incident_id=? ORDER BY created_utc DESC LIMIT 1",
        (incident_id,),
    ).fetchone()
    evidence = {
        "incident": dict(inc),
        "response_action": dict(ra) if ra else None,
        "alerts": [dict(a) for a in alerts],
    }
    data = json.dumps(evidence, indent=2, default=str).encode("utf-8")
    return send_file(
        BytesIO(data),
        mimetype="application/json",
        as_attachment=True,
        download_name=f"evidence-{incident_id}.json",
    )


@bp.route("/<incident_id>/report")
@login_required
def download_report(incident_id):
    db = get_db()
    inc = db.execute(
        "SELECT * FROM incidents WHERE incident_id=?", (incident_id,)
    ).fetchone()
    if not inc:
        abort(404)
    alerts = db.execute(
        "SELECT * FROM alerts WHERE src_ip=? AND timestamp_utc >= ? AND timestamp_utc <= ?",
        (inc["source_ip"], inc["first_seen_utc"], inc["last_seen_utc"]),
    ).fetchall()
    ra = db.execute(
        "SELECT * FROM response_actions WHERE incident_id=? ORDER BY created_utc DESC LIMIT 1",
        (incident_id,),
    ).fetchone()

    html = _render_incident_report(dict(inc), dict(ra) if ra else None, [dict(a) for a in alerts])
    return send_file(
        BytesIO(html.encode("utf-8")),
        mimetype="text/html",
        as_attachment=True,
        download_name=f"incident-report-{incident_id}.html",
    )


def _render_incident_report(inc: dict, ra: dict | None, alerts: list) -> str:
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    alerts_html = "".join(
        f"<tr><td>{a.get('timestamp_utc','')[:19]}</td>"
        f"<td>{a.get('rule_sid','')}</td>"
        f"<td>{a.get('rule_name','')}</td>"
        f"<td>{a.get('src_ip','')}</td>"
        f"<td>{a.get('http_url','')}</td></tr>"
        for a in alerts
    )
    ra_html = ""
    if ra:
        for k, v in ra.items():
            if k not in ("id",):
                ra_html += f"<tr><td>{k}</td><td>{v}</td></tr>"

    return f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8">
<title>Incident Report — {inc['incident_id']}</title>
<style>
  body{{font-family:sans-serif;max-width:900px;margin:40px auto;color:#1e293b;}}
  h1{{color:#1a2744;}} h2{{color:#3b6fd4;border-bottom:1px solid #e2e8f0;padding-bottom:4px;}}
  table{{border-collapse:collapse;width:100%;margin-bottom:16px;}}
  th{{background:#f8fafc;font-size:12px;text-transform:uppercase;padding:8px;border:1px solid #e2e8f0;}}
  td{{padding:8px;border:1px solid #e2e8f0;font-size:13px;}}
  .badge-red{{background:#fee2e2;color:#dc2626;padding:2px 8px;border-radius:12px;}}
  .note{{background:#fef3c7;border-left:4px solid #d97706;padding:10px;margin-bottom:12px;font-size:13px;}}
</style>
</head>
<body>
<h1>TalkTalk Lab — Mini-SIEM</h1>
<h2>Incident Report: {inc['incident_id']}</h2>
<p>Generated: {now}</p>
<div class="note">
  This report is generated from the Mini-SIEM database.
  Historical runs are imported from the verified evidence archive.
  Live runs are labelled separately.
  No credentials, cookies, or secrets are included.
</div>

<h2>Incident Summary</h2>
<table>
  <tr><th>Field</th><th>Value</th></tr>
  <tr><td>Incident ID</td><td>{inc['incident_id']}</td></tr>
  <tr><td>Severity</td><td><span class="badge-red">{inc['severity']}</span></td></tr>
  <tr><td>Status</td><td>{inc['status']}</td></tr>
  <tr><td>Source IP</td><td>{inc['source_ip']}</td></tr>
  <tr><td>First seen (UTC)</td><td>{inc['first_seen_utc']}</td></tr>
  <tr><td>Last seen (UTC)</td><td>{inc['last_seen_utc']}</td></tr>
  <tr><td>Alert count</td><td>{inc['alert_count']}</td></tr>
  <tr><td>Notes</td><td>{inc.get('notes') or '—'}</td></tr>
</table>

<h2>Response Action</h2>
{f'<table><tr><th>Field</th><th>Value</th></tr>{ra_html}</table>' if ra else '<p>No response action recorded.</p>'}

<h2>Related Alerts ({len(alerts)})</h2>
<table>
  <tr><th>Time (UTC)</th><th>SID</th><th>Rule name</th><th>Source</th><th>URL</th></tr>
  {alerts_html if alerts_html else '<tr><td colspan="5">No alerts linked.</td></tr>'}
</table>

<p style="font-size:11px;color:#94a3b8;margin-top:32px;">
  TalkTalk Lab — Mini-SIEM · M.Tech Cybersecurity Project
  · Report does not contain secrets, credentials, or raw capture data.
</p>
</body></html>"""
