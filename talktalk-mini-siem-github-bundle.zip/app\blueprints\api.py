"""
TalkTalk Lab — Mini-SIEM · API blueprint
Handles: status, run execution, incident management, response actions,
collector ingest, settings.
"""
import csv
import hashlib
import json
import logging
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path

from flask import Blueprint, current_app, jsonify, request
from flask_login import login_required
from flask_wtf.csrf import validate_csrf
from werkzeug.exceptions import BadRequest

from ..db import get_db, open_db_direct

log = logging.getLogger(__name__)
bp = Blueprint("api", __name__, url_prefix="/api")

# ── In-memory run state ───────────────────────────────────────────────────────
_run_lock = threading.Lock()
_active_run: dict | None = None  # {run_id, status, completed, total, current_case, last_result}


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _require_json_csrf():
    """Validate CSRF token from X-CSRFToken header for JSON API calls."""
    token = request.headers.get("X-CSRFToken", "")
    try:
        validate_csrf(token)
    except Exception:
        from flask import abort
        abort(403)


# ── Status endpoint ───────────────────────────────────────────────────────────
@bp.route("/status")
@login_required
def status():
    db = get_db()
    request_count = db.execute("SELECT COUNT(*) FROM case_results").fetchone()[0]
    alert_count = db.execute("SELECT COUNT(*) FROM alerts").fetchone()[0]
    incident_count = db.execute(
        "SELECT COUNT(*) FROM incidents WHERE status != 'resolved'"
    ).fetchone()[0]
    active_blocks = db.execute(
        "SELECT COUNT(*) FROM response_actions WHERE status IN ('applied','verified')"
    ).fetchone()[0]
    ar_row = db.execute(
        "SELECT value FROM siem_settings WHERE key='auto_response'"
    ).fetchone()
    return jsonify(
        {
            "request_count": request_count,
            "alert_count": alert_count,
            "incident_count": incident_count,
            "active_blocks": active_blocks,
            "auto_response": ar_row and ar_row[0] == "1",
        }
    )


# ── Run single test ───────────────────────────────────────────────────────────
@bp.route("/run/single", methods=["POST"])
@login_required
def run_single():
    _require_json_csrf()

    if current_app.config.get("FIXTURE_MODE"):
        return jsonify({"error": "Test execution disabled in fixture mode."}), 403

    data = request.get_json(force=True, silent=True) or {}
    case_id = data.get("case_id", "").strip()
    if not case_id:
        return jsonify({"error": "case_id required"}), 400

    # Load case from dataset
    case_data = _get_case(case_id)
    if not case_data:
        return jsonify({"error": f"Case '{case_id}' not found in dataset"}), 404

    # Prevent concurrent runs
    with _run_lock:
        global _active_run
        if _active_run and _active_run.get("status") == "running":
            return jsonify({"error": "A run is already in progress"}), 409

        run_id = f"live-{_utcnow()[:10].replace('-','')}-{uuid.uuid4().hex[:6]}"
        _active_run = {
            "run_id": run_id,
            "status": "running",
            "completed": 0,
            "total": 1,
            "current_case": case_id,
            "last_result": None,
        }

    db = get_db()
    _save_run_start(db, run_id, 1)

    from ..runner import execute_case
    result = execute_case(
        run_id=run_id,
        case=case_data,
        cfg=current_app.config,
        db_path=current_app.config["DATABASE"],
    )

    with _run_lock:
        _active_run["status"] = "complete"
        _active_run["completed"] = 1
        _active_run["last_result"] = result

    _save_run_finish(db, run_id)

    return jsonify(result)


# ── Run all 24 cases ──────────────────────────────────────────────────────────
@bp.route("/run/all", methods=["POST"])
@login_required
def run_all():
    _require_json_csrf()

    if current_app.config.get("FIXTURE_MODE"):
        return jsonify({"error": "Test execution disabled in fixture mode."}), 403

    with _run_lock:
        global _active_run
        if _active_run and _active_run.get("status") == "running":
            return jsonify({"error": "A run is already in progress"}), 409

        run_id = f"live-{_utcnow()[:10].replace('-','')}-{uuid.uuid4().hex[:6]}"
        _active_run = {
            "run_id": run_id,
            "status": "running",
            "completed": 0,
            "total": 24,
            "current_case": None,
            "last_result": None,
        }

    cases = _load_all_cases()
    if not cases:
        with _run_lock:
            _active_run["status"] = "error"
        return jsonify({"error": "Could not load dataset"}), 500

    db = get_db()
    _save_run_start(db, run_id, len(cases))

    # Run in background thread
    t = threading.Thread(
        target=_run_all_background,
        args=(run_id, cases, current_app.config.copy(), current_app.config["DATABASE"]),
        daemon=True,
    )
    t.start()

    return jsonify({"run_id": run_id, "status": "running", "total": len(cases)})


def _run_all_background(run_id: str, cases: list, cfg: dict, db_path: str):
    global _active_run
    from ..runner import execute_case
    import time

    conn = open_db_direct(db_path)
    try:
        for i, case in enumerate(cases):
            with _run_lock:
                if _active_run and _active_run.get("status") == "cancelled":
                    break
                if _active_run:
                    _active_run["current_case"] = case["case_id"]

            result = execute_case(
                run_id=run_id, case=case, cfg=cfg, db_path=db_path
            )

            with _run_lock:
                if _active_run:
                    _active_run["completed"] = i + 1
                    _active_run["last_result"] = result

            time.sleep(cfg.get("CASE_INTERVAL_SECONDS", 0.5))

        with _run_lock:
            if _active_run and _active_run.get("status") != "cancelled":
                _active_run["status"] = "complete"

        conn.execute(
            "UPDATE runs SET status='complete', finished_utc=? WHERE run_id=?",
            (_utcnow(), run_id),
        )
        conn.commit()
    except Exception as e:
        log.exception("Background run failed: %s", e)
        with _run_lock:
            if _active_run:
                _active_run["status"] = "error"
        conn.execute(
            "UPDATE runs SET status='error', finished_utc=? WHERE run_id=?",
            (_utcnow(), run_id),
        )
        conn.commit()
    finally:
        conn.close()


# ── Run status polling ────────────────────────────────────────────────────────
@bp.route("/run/status/<run_id>")
@login_required
def run_status(run_id):
    with _run_lock:
        if _active_run and _active_run.get("run_id") == run_id:
            return jsonify(
                {
                    "run_id": run_id,
                    "status": _active_run["status"],
                    "completed": _active_run["completed"],
                    "total": _active_run["total"],
                    "current_case": _active_run["current_case"],
                    "last_result": _active_run["last_result"],
                }
            )
    # Fallback: query DB
    db = get_db()
    run = db.execute("SELECT * FROM runs WHERE run_id=?", (run_id,)).fetchone()
    if not run:
        return jsonify({"error": "not found"}), 404
    return jsonify(
        {
            "run_id": run_id,
            "status": run["status"],
            "completed": run["case_count"],
            "total": run["case_count"],
        }
    )


# ── Cancel run ────────────────────────────────────────────────────────────────
@bp.route("/run/cancel/<run_id>", methods=["POST"])
@login_required
def cancel_run(run_id):
    _require_json_csrf()
    with _run_lock:
        global _active_run
        if _active_run and _active_run.get("run_id") == run_id:
            _active_run["status"] = "cancelled"
    db = get_db()
    db.execute(
        "UPDATE runs SET status='cancelled', finished_utc=? WHERE run_id=? AND status='running'",
        (_utcnow(), run_id),
    )
    db.commit()
    return jsonify({"ok": True})


# ── Collector ingest (called by Ubuntu collector) ─────────────────────────────
@bp.route("/collector/ingest", methods=["POST"])
def collector_ingest():
    """Ubuntu collector pushes events here. Authenticated by token header."""
    token = request.headers.get("X-Collector-Token", "")
    expected = current_app.config.get("COLLECTOR_TOKEN", "")
    if not expected or token != expected:
        return jsonify({"error": "unauthorized"}), 401

    data = request.get_json(force=True, silent=True)
    if not data or "events" not in data:
        return jsonify({"error": "bad request"}), 400

    db = get_db()
    accepted = skipped = 0

    for ev in data["events"]:
        source = ev.get("source", "")
        if source not in ("apache", "suricata"):
            continue

        dedup_key = ev.get("dedup_key") or hashlib.sha256(
            json.dumps(ev, sort_keys=True).encode()
        ).hexdigest()

        try:
            db.execute(
                "INSERT OR IGNORE INTO events "
                "(source, event_type, raw, timestamp_utc, dedup_key, ingested_utc) "
                "VALUES (?,?,?,?,?,?)",
                (
                    source,
                    ev.get("event_type", ""),
                    json.dumps(ev),
                    ev.get("timestamp_utc", _utcnow()),
                    dedup_key,
                    _utcnow(),
                ),
            )

            # If this is a Suricata alert, also insert into alerts table
            if source == "suricata" and ev.get("event_type") == "alert":
                _ingest_suricata_alert(db, ev, dedup_key)

            accepted += 1
        except Exception as e:
            log.warning("Ingest error: %s", e)
            skipped += 1

    db.execute(
        "UPDATE siem_settings SET value=? WHERE key='collector_fresh_utc'",
        (_utcnow(),),
    )
    db.commit()

    # Check for incident thresholds
    _check_incident_threshold(db)

    return jsonify({"accepted": accepted, "skipped": skipped})


def _ingest_suricata_alert(db, ev: dict, dedup_key: str):
    alert_id = ev.get("alert_id") or dedup_key
    try:
        db.execute(
            "INSERT OR IGNORE INTO alerts "
            "(alert_id, timestamp_utc, rule_sid, rule_name, severity, "
            "src_ip, dst_ip, dst_port, proto, http_url, http_method, "
            "run_id, case_id, raw, ingested_utc) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                alert_id,
                ev.get("timestamp_utc", _utcnow()),
                ev.get("rule_sid"),
                ev.get("rule_name"),
                ev.get("severity", 2),
                ev.get("src_ip"),
                ev.get("dst_ip"),
                ev.get("dst_port"),
                ev.get("proto"),
                ev.get("http_url"),
                ev.get("http_method"),
                ev.get("run_id"),
                ev.get("case_id"),
                json.dumps(ev),
                _utcnow(),
            ),
        )
    except Exception as e:
        log.warning("Alert ingest error: %s", e)


def _check_incident_threshold(db):
    """Group recent SQLi alerts into incidents if threshold met."""
    from flask import current_app
    threshold = current_app.config.get("INCIDENT_THRESHOLD", 3)
    window_sec = current_app.config.get("INCIDENT_WINDOW_SECONDS", 60)

    # Find alert groups by src_ip within window
    alert_groups = db.execute(
        "SELECT src_ip, COUNT(*) as cnt, MIN(timestamp_utc) as first_ts, "
        "MAX(timestamp_utc) as last_ts "
        "FROM alerts "
        "WHERE ingested_utc >= datetime('now', ? || ' seconds') "
        "GROUP BY src_ip "
        "HAVING cnt >= ?",
        (f"-{window_sec}", threshold),
    ).fetchall()

    for grp in alert_groups:
        src = grp["src_ip"]
        # Check if incident already exists for this source in this window
        existing = db.execute(
            "SELECT id FROM incidents WHERE source_ip=? "
            "AND first_seen_utc >= datetime('now', ? || ' seconds')",
            (src, f"-{window_sec}"),
        ).fetchone()
        if existing:
            # Update alert count
            db.execute(
                "UPDATE incidents SET alert_count=?, last_seen_utc=?, updated_utc=? "
                "WHERE source_ip=? "
                "AND first_seen_utc >= datetime('now', ? || ' seconds')",
                (grp["cnt"], grp["last_ts"], _utcnow(), src, f"-{window_sec}"),
            )
        else:
            inc_id = f"INC-{uuid.uuid4().hex[:6].upper()}"
            db.execute(
                "INSERT INTO incidents "
                "(incident_id, severity, status, source_ip, first_seen_utc, "
                "last_seen_utc, alert_count, created_utc, updated_utc) "
                "VALUES (?,?,?,?,?,?,?,?,?)",
                (
                    inc_id, "high", "open", src,
                    grp["first_ts"], grp["last_ts"],
                    grp["cnt"], _utcnow(), _utcnow(),
                ),
            )
            db.execute(
                "INSERT INTO audit_log (actor, action, detail, created_utc) "
                "VALUES (?,?,?,?)",
                ("system", "incident_created", f"{inc_id} from {src}", _utcnow()),
            )
            # If auto-response is enabled, trigger block
            ar_row = db.execute(
                "SELECT value FROM siem_settings WHERE key='auto_response'"
            ).fetchone()
            if ar_row and ar_row[0] == "1" and not current_app.config.get("FIXTURE_MODE"):
                _trigger_block_for_incident(db, inc_id, src)

    db.commit()


def _trigger_block_for_incident(db, incident_id: str, source_ip: str):
    """Request firewall block via Ubuntu response helper."""
    from .response import request_block
    cfg = current_app.config
    # Validate scope
    if source_ip != cfg.get("BLOCK_SOURCE_IP"):
        log.warning("Block request for unexpected source %s — rejected", source_ip)
        return
    request_block(db, incident_id, source_ip, cfg)


# ── Settings ───────────────────────────────────────────────────────────────────
@bp.route("/settings/auto_response", methods=["POST"])
@login_required
def set_auto_response():
    _require_json_csrf()
    if current_app.config.get("FIXTURE_MODE"):
        return jsonify({"ok": False, "error": "Disabled in fixture mode"}), 403

    data = request.get_json(force=True, silent=True) or {}
    enabled = bool(data.get("enabled", False))
    db = get_db()
    db.execute(
        "UPDATE siem_settings SET value=? WHERE key='auto_response'",
        ("1" if enabled else "0",),
    )
    db.execute(
        "INSERT INTO audit_log (actor, action, detail, created_utc) VALUES (?,?,?,?)",
        ("operator", "set_auto_response", str(enabled), _utcnow()),
    )
    db.commit()
    return jsonify({"ok": True, "auto_response": enabled})


# ── Incident status update ─────────────────────────────────────────────────────
@bp.route("/incidents/<incident_id>/status", methods=["POST"])
@login_required
def update_incident_status(incident_id):
    _require_json_csrf()
    data = request.get_json(force=True, silent=True) or {}
    status = data.get("status", "")
    if status not in ("open", "acknowledged", "resolved"):
        return jsonify({"ok": False, "error": "Invalid status"}), 400
    db = get_db()
    db.execute(
        "UPDATE incidents SET status=?, updated_utc=? WHERE incident_id=?",
        (status, _utcnow(), incident_id),
    )
    db.execute(
        "INSERT INTO audit_log (actor, action, detail, created_utc) VALUES (?,?,?,?)",
        ("operator", "update_incident_status", f"{incident_id}={status}", _utcnow()),
    )
    db.commit()
    return jsonify({"ok": True})


# ── Manual block/unblock ───────────────────────────────────────────────────────
@bp.route("/response/block", methods=["POST"])
@login_required
def manual_block():
    _require_json_csrf()
    if current_app.config.get("FIXTURE_MODE"):
        return jsonify({"ok": False, "error": "Disabled in fixture mode"}), 403

    data = request.get_json(force=True, silent=True) or {}
    incident_id = data.get("incident_id", "")
    db = get_db()
    inc = db.execute(
        "SELECT * FROM incidents WHERE incident_id=?", (incident_id,)
    ).fetchone()
    if not inc:
        return jsonify({"ok": False, "error": "Incident not found"}), 404

    from .response import request_block
    success, detail = request_block(
        db, incident_id, inc["source_ip"], current_app.config
    )
    db.commit()
    return jsonify({"ok": success, "detail": detail})


@bp.route("/response/unblock", methods=["POST"])
@login_required
def manual_unblock():
    _require_json_csrf()
    if current_app.config.get("FIXTURE_MODE"):
        return jsonify({"ok": False, "error": "Disabled in fixture mode"}), 403

    data = request.get_json(force=True, silent=True) or {}
    incident_id = data.get("incident_id", "")
    source_ip = data.get("source_ip", "")

    # Validate address scope
    cfg = current_app.config
    if source_ip != cfg.get("BLOCK_SOURCE_IP"):
        return jsonify({"ok": False, "error": f"Source IP {source_ip} is not in the allowed scope"}), 403

    db = get_db()
    from .response import request_unblock
    success, verification = request_unblock(db, incident_id, source_ip, cfg)
    db.commit()
    return jsonify({"ok": success, "verification": verification})


# ── Helpers ────────────────────────────────────────────────────────────────────
def _get_case(case_id: str) -> dict | None:
    for c in _load_all_cases():
        if c["case_id"] == case_id:
            return c
    return None


def _load_all_cases() -> list:
    from flask import current_app
    path = current_app.config.get("CASES_CSV", "")
    if not Path(path).exists():
        alt = Path(
            r"C:\Users\HP\.gemini\antigravity\scratch\talktalk-zip-extract\traffic\cases.csv"
        )
        if alt.exists():
            path = str(alt)
        else:
            return []
    cases = []
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            cases.append(row)
    return cases


def _save_run_start(db, run_id: str, case_count: int):
    app_state = db.execute(
        "SELECT state, php_sha256 FROM app_state WHERE id=1"
    ).fetchone()
    mode = "live_patched" if (app_state and app_state["state"] == "patched") else "live_vulnerable"
    from config import EXPECTED_DATASET_SHA256, EXPECTED_RULES_SHA256

    db.execute(
        "INSERT OR IGNORE INTO runs "
        "(run_id, mode, source, started_utc, status, dataset_sha256, rules_sha256, "
        "app_sha256, auto_response, case_count, created_utc) "
        "VALUES (?,?,?,?,?,?,?,?,0,?,?)",
        (
            run_id, mode, "live", _utcnow(), "running",
            EXPECTED_DATASET_SHA256, EXPECTED_RULES_SHA256,
            app_state["php_sha256"] if app_state else None,
            case_count, _utcnow(),
        ),
    )
    db.commit()


def _save_run_finish(db, run_id: str):
    db.execute(
        "UPDATE runs SET status='complete', finished_utc=? WHERE run_id=?",
        (_utcnow(), run_id),
    )
    db.commit()
