$ErrorActionPreference = 'Stop'
$base = 'http://192.168.77.10/DVWA'
$root = 'D:\TalkTalk-Lab\traffic'
$caseFile = Join-Path $root 'cases.csv'
$expectedHash = 'B956230B821338CDAA760AD501C1492A7464DF885840F9935256AF17C9CE095B'

if ((Get-FileHash $caseFile -Algorithm SHA256).Hash -ne $expectedHash) {
    throw 'Dataset changed. Stop and check cases.csv.'
}

$cases = @(Import-Csv $caseFile)
$runId = 'baseline-' + [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfffZ')
$out = Join-Path $root $runId
New-Item -ItemType Directory -Path $out | Out-Null
Copy-Item $caseFile (Join-Path $out 'cases.csv')
Copy-Item $PSCommandPath (Join-Path $out 'runner.ps1')

function Get-Token([string]$html) {
    $tag = [regex]::Match(
        $html, '(?is)<input\b[^>]*\bname=["'']user_token["''][^>]*>'
    ).Value
    $value = [regex]::Match(
        $tag, '\bvalue=["'']([^"'']+)["'']'
    )
    if (-not $value.Success) {
        throw 'DVWA form token was not found.'
    }
    return $value.Groups[1].Value
}

$session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$requestOptions = @{
    WebSession = $session
    UseBasicParsing = $true
    TimeoutSec = 20
    ErrorAction = 'Stop'
}

# Log in using the lab's DVWA web account.
$page = Invoke-WebRequest @requestOptions -Uri "$base/login.php"
$loginBody = @{
    username = 'admin'
    password = 'password'
    Login = 'Login'
    user_token = (Get-Token $page.Content)
}
$page = Invoke-WebRequest @requestOptions -Uri "$base/login.php" `
    -Method Post -Body $loginBody

if ($page.Content -notmatch 'logout\.php') {
    throw 'DVWA login was not confirmed.'
}

# Set Low in this runner's own session.
$page = Invoke-WebRequest @requestOptions -Uri "$base/security.php"
$securityBody = @{
    security = 'low'
    seclev_submit = 'Submit'
    user_token = (Get-Token $page.Content)
}
$page = Invoke-WebRequest @requestOptions -Uri "$base/security.php" `
    -Method Post -Body $securityBody

if ($page.Content -notmatch 'Security level is currently:\s*<em>low</em>') {
    throw 'DVWA Low security was not confirmed.'
}

@{
    run_id = $runId
    security = 'low'
    dataset_sha256 = $expectedHash
    expected_requests = $cases.Count
    started_utc = [DateTime]::UtcNow.ToString('o')
} | ConvertTo-Json | Set-Content (Join-Path $out 'run.json') -Encoding UTF8

$results = Join-Path $out 'responses.csv'

foreach ($case in $cases) {
    $encoded = [Uri]::EscapeDataString($case.input)
    $uri = "$base/vulnerabilities/sqli/?id=$encoded&Submit=Submit"
    $uri += "&tt_run=$runId&tt_case=$($case.case_id)"

    $started = [DateTime]::UtcNow.ToString('o')
    $timer = [Diagnostics.Stopwatch]::StartNew()

    try {
        $response = Invoke-WebRequest @requestOptions -Uri $uri
        $timer.Stop()

        $htmlFile = "$($case.case_id).html"
        $response.Content | Set-Content `
            (Join-Path $out $htmlFile) -Encoding UTF8

        if ($response.Content -notmatch '<h1>Vulnerability: SQL Injection</h1>') {
            throw "Unexpected page for $($case.case_id). Inspect $htmlFile."
        }

        $records = [regex]::Matches(
            $response.Content, 'First name:'
        ).Count

        [pscustomobject]@{
            run_id = $runId
            case_id = $case.case_id
            label = $case.label
            family = $case.family
            input = $case.input
            started_utc = $started
            finished_utc = [DateTime]::UtcNow.ToString('o')
            http_status = [int]$response.StatusCode
            response_ms = [math]::Round($timer.Elapsed.TotalMilliseconds, 2)
            records = $records
            response_file = $htmlFile
            request_url = $uri
        } | Export-Csv $results -Append -NoTypeInformation -Encoding UTF8

        Write-Host "$($case.case_id): HTTP $($response.StatusCode), records=$records"
    }
    catch {
        $timer.Stop()
        $_ | Out-String | Set-Content `
            (Join-Path $out 'RUN-INCOMPLETE.txt') -Encoding UTF8
        throw
    }

    Start-Sleep -Milliseconds 500
}

"Completed $($cases.Count) cases at $([DateTime]::UtcNow.ToString('o'))" |
    Set-Content (Join-Path $out 'COMPLETE.txt') -Encoding UTF8

Write-Host "`nRun ID: $runId"
Write-Host "Evidence folder: $out"
Import-Csv $results | Group-Object label,http_status |
    Select-Object Name,Count