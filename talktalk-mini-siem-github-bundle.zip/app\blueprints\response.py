"""
TalkTalk Lab — Mini-SIEM · Response module
Handles firewall block/unblock via Ubuntu response helper.
Validates scope strictly — only 192.168.77.1 → port 80 on lab host.
All actions are audited.
"""
import logging
import socket
from datetime import datetime, timezone, timedelta
import requests as http_requests

log = logging.getLogger(__name__)


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _validate_scope(source_ip: str, cfg: dict) -> bool:
    """Only allow blocking the configured lab test source IP."""
    return source_ip == cfg.get("BLOCK_SOURCE_IP", "192.168.77.1")


def request_block(db, incident_id: str, source_ip: str, cfg: dict) -> tuple[bool, str]:
    """Request a temporary firewall block via the Ubuntu response helper."""
    if not _validate_scope(source_ip, cfg):
        detail = f"Source IP {source_ip} is outside allowed scope — block rejected"
        log.warning(detail)
        _audit(db, "system", "block_rejected", detail)
        return False, detail

    target_ip = cfg.get("BLOCK_TARGET_IP", "192.168.77.10")
    target_port = cfg.get("BLOCK_TARGET_PORT", 80)
    duration = cfg.get("BLOCK_DURATION_SECONDS", 60)
    now = _utcnow()
    expires = (
        datetime.now(timezone.utc) + timedelta(seconds=duration)
    ).isoformat()

    # Insert response_action as requested
    db.execute(
        "INSERT INTO response_actions "
        "(incident_id, action, status, source_ip, target_ip, target_port, "
        "duration_sec, requested_utc, expires_utc, created_utc) "
        "VALUES (?,?,?,?,?,?,?,?,?,?)",
        (
            incident_id, "block", "requested",
            source_ip, target_ip, target_port,
            duration, now, expires, now,
        ),
    )
    ra_id = db.execute(
        "SELECT last_insert_rowid()"
    ).fetchone()[0]
    _audit(db, "system", "block_requested", f"{incident_id} src={source_ip}")

    # Call Ubuntu helper
    helper_url = cfg.get("RESPONSE_HELPER_URL", "")
    helper_token = cfg.get("RESPONSE_HELPER_TOKEN", "")

    if not helper_url:
        _update_ra(db, ra_id, "failed", error="Response helper URL not configured")
        return False, "Response helper not configured"

    try:
        resp = http_requests.post(
            f"{helper_url}/block",
            json={
                "source_ip": source_ip,
                "target_port": target_port,
                "duration_sec": duration,
                "incident_id": incident_id,
            },
            headers={"X-Helper-Token": helper_token},
            timeout=15,
        )
        if resp.status_code == 200 and resp.json().get("ok"):
            _update_ra(db, ra_id, "applied", applied_utc=_utcnow())
            _audit(db, "system", "block_applied", f"{incident_id} src={source_ip}")

            # Verify by attempting a fresh connection
            verification = _verify_block(source_ip, target_ip, target_port, cfg)
            _update_ra(db, ra_id, "verified", verification=verification, verified_utc=_utcnow())
            _audit(db, "system", "block_verified", f"{incident_id} result={verification}")
            return True, verification
        else:
            err = resp.text[:200]
            _update_ra(db, ra_id, "failed", error=err)
            return False, f"Helper returned error: {err}"
    except http_requests.exceptions.Timeout:
        _update_ra(db, ra_id, "failed", error="timeout contacting helper")
        return False, "Timeout contacting response helper"
    except http_requests.exceptions.ConnectionError:
        _update_ra(db, ra_id, "failed", error="connection refused to helper")
        return False, "Connection refused to response helper"
    except Exception as e:
        _update_ra(db, ra_id, "failed", error=str(e)[:200])
        return False, f"Helper error: {e}"


def request_unblock(
    db, incident_id: str, source_ip: str, cfg: dict
) -> tuple[bool, str]:
    """Remove a firewall block via the Ubuntu response helper."""
    helper_url = cfg.get("RESPONSE_HELPER_URL", "")
    helper_token = cfg.get("RESPONSE_HELPER_TOKEN", "")

    if not helper_url:
        return False, "Response helper not configured"

    now = _utcnow()
    try:
        resp = http_requests.post(
            f"{helper_url}/unblock",
            json={"source_ip": source_ip, "incident_id": incident_id},
            headers={"X-Helper-Token": helper_token},
            timeout=15,
        )
        if resp.status_code == 200 and resp.json().get("ok"):
            db.execute(
                "UPDATE response_actions SET status='manually_removed', removed_utc=? "
                "WHERE incident_id=? AND status IN ('applied','verified')",
                (now, incident_id),
            )
            _audit(
                db, "operator", "block_removed",
                f"{incident_id} src={source_ip}"
            )
            # Verify restored access
            target_ip = cfg.get("BLOCK_TARGET_IP", "192.168.77.10")
            target_port = cfg.get("BLOCK_TARGET_PORT", 80)
            verification = _verify_access_restored(source_ip, target_ip, target_port)
            return True, verification
        else:
            return False, resp.text[:200]
    except http_requests.exceptions.Timeout:
        return False, "Timeout contacting response helper"
    except http_requests.exceptions.ConnectionError:
        return False, "Connection refused to response helper"
    except Exception as e:
        return False, str(e)[:200]


def _verify_block(
    source_ip: str, target_ip: str, target_port: int, cfg: dict
) -> str:
    """
    Attempt a fresh TCP connection to verify the block is in place.
    Returns 'blocked' | 'timeout' | 'refused' | 'still_open' | 'other'.
    """
    try:
        s = socket.create_connection((target_ip, target_port), timeout=3)
        s.close()
        return "still_open"
    except socket.timeout:
        return "timeout"
    except ConnectionRefusedError:
        return "refused"
    except OSError:
        return "blocked"
    except Exception:
        return "other"


def _verify_access_restored(source_ip: str, target_ip: str, target_port: int) -> str:
    try:
        s = socket.create_connection((target_ip, target_port), timeout=3)
        s.close()
        return "access_restored"
    except Exception:
        return "still_blocked"


def _update_ra(
    db,
    ra_id: int,
    status: str,
    applied_utc: str = None,
    verified_utc: str = None,
    verification: str = None,
    error: str = None,
):
    db.execute(
        "UPDATE response_actions SET status=?, applied_utc=COALESCE(?,applied_utc), "
        "verified_utc=COALESCE(?,verified_utc), verification=COALESCE(?,verification), "
        "error=COALESCE(?,error) WHERE id=?",
        (status, applied_utc, verified_utc, verification, error, ra_id),
    )


def _audit(db, actor: str, action: str, detail: str):
    db.execute(
        "INSERT INTO audit_log (actor, action, detail, created_utc) VALUES (?,?,?,?)",
        (actor, action, detail, _utcnow()),
    )
